import api from './api'

export const contentService = {
  async generateScript(data: {
    prompt: string
    duration_minutes?:  number
    style?: string
  }) {
    const response = await api.post('/content/script', data)
    return response. data
  },

  async generateVariants(data: {
    prompt: string
    num_variants?: number
  }) {
    const response = await api.post('/content/variants', data)
    return response.data
  },

  async generateStoryboard(prompt: string) {
    const response = await api.post('/content/storyboard', { prompt })
    return response.data
  },
}