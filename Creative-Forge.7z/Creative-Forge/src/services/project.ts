import api from './api'

export const projectService = {
  async createProject(data: {
    title: string
    description?:  string
    category?:  string
  }) {
    const response = await api.post('/projects', data)
    return response.data
  },

  async listProjects(skip = 0, limit = 20) {
    const response = await api.get(`/projects?skip=${skip}&limit=${limit}`)
    return response.data
  },

  async getProject(projectId: number) {
    const response = await api.get(`/projects/${projectId}`)
    return response.data
  },

  async updateProject(projectId:  number, data: any) {
    const response = await api.put(`/projects/${projectId}`, data)
    return response.data
  },

  async deleteProject(projectId: number) {
    await api.delete(`/projects/${projectId}`)
  },

  async getStats(projectId: number) {
    const response = await api.get(`/projects/${projectId}/stats`)
    return response.data
  },
}