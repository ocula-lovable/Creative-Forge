import api from './api'

export const authService = {
  async login(email: string, password:  string) {
    const response = await api.post('/auth/login', { email, password })
    return response.data
  },

  async signup(email: string, username: string, password: string, fullName?:  string) {
    const response = await api.post('/auth/signup', {
      email,
      username,
      password,
      full_name: fullName,
    })
    return response.data
  },

  async getMe() {
    const response = await api.get('/auth/me')
    return response.data
  },

  async updateProfile(data: any) {
    const response = await api.put('/users/me', data)
    return response. data
  },

  async logout() {
    await api.post('/auth/logout')
  },

  async refreshToken(refreshToken: string) {
    const response = await api.post('/auth/refresh', { refresh_token: refreshToken })
    return response.data
  },
}