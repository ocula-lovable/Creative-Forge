import api from './api'

export const videoService = {
  async createVideo(data: {
    project_id: number
    title:  string
    description?: string
    prompt: string
    video_type?:  string
  }) {
    const response = await api.post('/videos', data)
    return response.data
  },

  async listVideos(projectId?:  number, skip = 0, limit = 20) {
    const params = new URLSearchParams()
    if (projectId) params.append('project_id', projectId.toString())
    params.append('skip', skip.toString())
    params.append('limit', limit.toString())

    const response = await api.get(`/videos?${params}`)
    return response.data
  },

  async getVideo(videoId: number) {
    const response = await api.get(`/videos/${videoId}`)
    return response.data
  },

  async updateVideo(videoId: number, data: any) {
    const response = await api. put(`/videos/${videoId}`, data)
    return response.data
  },

  async deleteVideo(videoId: number) {
    await api.delete(`/videos/${videoId}`)
  },

  async regenerateVideo(videoId: number) {
    const response = await api.post(`/videos/${videoId}/regenerate`)
    return response.data
  },
}