import api from './api'

export const adService = {
  async generateAds(data: {
    project_id: number
    product_name: string
    target_audience: string
    platform: string
    style?:  string
  }) {
    const response = await api.post('/ads/generate', data)
    return response.data
  },

  async getPlatformPreset(platform: string) {
    const response = await api.post('/ads/platform-preset', { platform })
    return response.data
  },
}