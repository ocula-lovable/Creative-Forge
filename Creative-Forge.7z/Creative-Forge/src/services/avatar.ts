import api from './api'

export const avatarService = {
  async createAvatar(data:  {
    project_id: number
    name: string
    description?: string
    gender?:  string
    ethnicity?: string
    voice_id?: string
    voice_name?: string
    language?: string
  }) {
    const response = await api.post('/avatars', data)
    return response.data
  },

  async listAvatars(projectId?: number, skip = 0, limit = 20) {
    const params = new URLSearchParams()
    if (projectId) params.append('project_id', projectId.toString())
    params.append('skip', skip.toString())
    params.append('limit', limit.toString())

    const response = await api. get(`/avatars?${params}`)
    return response.data
  },

  async getAvatar(avatarId: number) {
    const response = await api.get(`/avatars/${avatarId}`)
    return response.data
  },

  async updateAvatar(avatarId:  number, data: any) {
    const response = await api.put(`/avatars/${avatarId}`, data)
    return response.data
  },

  async deleteAvatar(avatarId:  number) {
    await api.delete(`/avatars/${avatarId}`)
  },

  async generateVideo(avatarId: number, data: { script: string; voice_id?: string }) {
    const response = await api.post(`/avatars/${avatarId}/generate-video`, data)
    return response.data
  },

  async getVoices() {
    const response = await api.get('/avatars/0/voices')
    return response. data
  },
}