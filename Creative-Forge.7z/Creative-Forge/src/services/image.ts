import api from './api'

export const imageService = {
  async createImage(data: {
    project_id: number
    title: string
    description?: string
    prompt: string
    image_type?: string
    style?: string
  }) {
    const response = await api.post('/images', data)
    return response.data
  },

  async listImages(projectId?: number, skip = 0, limit = 20) {
    const params = new URLSearchParams()
    if (projectId) params.append('project_id', projectId.toString())
    params.append('skip', skip.toString())
    params.append('limit', limit.toString())

    const response = await api.get(`/images?${params}`)
    return response.data
  },

  async getImage(imageId: number) {
    const response = await api.get(`/images/${imageId}`)
    return response.data
  },

  async updateImage(imageId: number, data: any) {
    const response = await api.put(`/images/${imageId}`, data)
    return response.data
  },

  async deleteImage(imageId: number) {
    await api.delete(`/images/${imageId}`)
  },
}