import React, { createContext, useState, useCallback } from 'react'

export interface Project {
  id:  number
  title: string
  description: string
  status: string
  category: string
  thumbnail_url: string
  created_at: string
  updated_at: string
  videos_count?:  number
  images_count?: number
  assets_count?: number
}

export interface ProjectContextType {
  currentProject: Project | null
  projects: Project[]
  setCurrentProject: (project: Project | null) => void
  addProject: (project: Project) => void
  updateProject:  (project: Project) => void
  removeProject: (projectId: number) => void
  setProjects: (projects: Project[]) => void
}

export const ProjectContext = createContext<ProjectContextType | undefined>(undefined)

export const ProjectProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentProject, setCurrentProject] = useState<Project | null>(null)
  const [projects, setProjects] = useState<Project[]>([])

  const addProject = useCallback((project: Project) => {
    setProjects(prev => [project, ...prev])
  }, [])

  const updateProject = useCallback((project: Project) => {
    setProjects(prev => prev.map(p => p.id === project.id ? project : p))
    if (currentProject?.id === project.id) {
      setCurrentProject(project)
    }
  }, [currentProject])

  const removeProject = useCallback((projectId: number) => {
    setProjects(prev => prev.filter(p => p.id !== projectId))
    if (currentProject?.id === projectId) {
      setCurrentProject(null)
    }
  }, [currentProject])

  return (
    <ProjectContext.Provider
      value={{
        currentProject,
        projects,
        setCurrentProject,
        addProject,
        updateProject,
        removeProject,
        setProjects,
      }}
    >
      {children}
    </ProjectContext.Provider>
  )
}