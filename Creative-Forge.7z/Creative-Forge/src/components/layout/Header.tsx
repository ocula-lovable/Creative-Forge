import { useState } from 'react'
import { useAuth } from '../../hooks/useAuth'
import { Link, useNavigate } from 'react-router-dom'

export default function Header() {
  const { user, logout } = useAuth()
  const navigate = useNavigate()
  const [showDropdown, setShowDropdown] = useState(false)
  const [showNotifications, setShowNotifications] = useState(false)

  const handleLogout = () => {
    logout()
    navigate('/')
  }

  return (
    <header className="bg-white border-b border-gray-200 sticky top-0 z-40">
      <div className="flex items-center justify-between px-6 py-4">
        {/* Logo */}
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-purple-600 rounded-lg"></div>
          <span className="font-bold text-lg">Creative Forge</span>
        </div>

        {/* Center - Search */}
        <div className="flex-1 mx-8">
          <input
            type="text"
            placeholder="Search projects, videos..."
            className="w-full max-w-md px-4 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:border-blue-500"
          />
        </div>

        {/* Right - User Menu */}
        <div className="flex items-center gap-4">
          {/* Notifications */}
          <div className="relative">
            <button
              onClick={() => setShowNotifications(!showNotifications)}
              className="relative text-gray-600 hover:text-gray-900 transition"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-. 214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
              </svg>
              <span className="absolute top-0 right-0 w-2 h-2 bg-red-500 rounded-full"></span>
            </button>

            {showNotifications && (
              <div className="absolute right-0 mt-2 w-80 bg-white rounded-lg shadow-xl p-4 max-h-96 overflow-y-auto">
                <h3 className="font-semibold mb-4">Notifications</h3>
                <div className="space-y-2">
                  <p className="text-gray-600 text-sm">No new notifications</p>
                </div>
              </div>
            )}
          </div>

          {/* Credits */}
          <div className="flex items-center gap-2 px-3 py-1 bg-blue-50 rounded-lg">
            <span className="text-sm font-semibold text-blue-600">
              {(user?.available_credits || 0).toFixed(1)} credits
            </span>
          </div>

          {/* User Dropdown */}
          <div className="relative">
            <button
              onClick={() => setShowDropdown(! showDropdown)}
              className="flex items-center gap-2 hover:bg-gray-100 px-3 py-2 rounded-lg transition"
            >
              <img
                src={user?.avatar_url || `https://ui-avatars.com/api/? name=${user?.username || 'User'}&background=random`}
                alt={user?.username}
                className="w-8 h-8 rounded-full"
              />
              <span className="text-sm font-medium hidden sm:inline">{user?.username}</span>
            </button>

            {showDropdown && (
              <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-xl overflow-hidden z-50">
                <Link to="/profile" className="block px-4 py-2 hover:bg-gray-100 text-sm font-medium">
                  Profile
                </Link>
                <Link to="/settings" className="block px-4 py-2 hover:bg-gray-100 text-sm font-medium">
                  Settings
                </Link>
                <Link to="/billing" className="block px-4 py-2 hover:bg-gray-100 text-sm font-medium">
                  Billing
                </Link>
                <hr className="my-2" />
                <button
                  onClick={handleLogout}
                  className="w-full text-left px-4 py-2 hover:bg-gray-100 text-sm font-medium text-red-600"
                >
                  Logout
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  )
}