import { Link, useLocation } from 'react-router-dom'
import { useState } from 'react'

const menuItems = [
  { label: 'Dashboard', icon: '📊', href: '/dashboard' },
  { label: 'Projects', icon:  '📁', href: '/projects' },
  {
    label: 'Create',
    icon: '✨',
    submenu: [
      { label:  'Video', icon: '🎬', href: '/videos/generator' },
      { label: 'Image', icon: '🖼️', href: '/images/generator' },
      { label: 'Avatar', icon: '👤', href: '/avatars/studio' },
      { label: 'Ad', icon: '📱', href: '/ads/generator' },
      { label: 'Content', icon: '📝', href: '/content/generator' },
    ],
  },
  { label: 'Video Editor', icon: '✂️', href: '/videos/editor' },
  { label: 'Assets', icon: '📦', href: '/assets' },
  { label: 'Templates', icon: '🎨', href: '/templates' },
  { label: 'History', icon: '⏰', href: '/history' },
  { label: 'Settings', icon: '⚙️', href: '/settings' },
]

export default function Sidebar() {
  const location = useLocation()
  const [expandedMenu, setExpandedMenu] = useState<string | null>(null)

  return (
    <aside className="w-64 bg-white border-r border-gray-200 overflow-y-auto">
      <div className="p-6">
        <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
          Forge
        </h1>
      </div>

      <nav className="px-4 space-y-2">
        {menuItems.map((item) => (
          <div key={item.label}>
            {item.submenu ?  (
              <button
                onClick={() => setExpandedMenu(expandedMenu === item. label ? null : item.label)}
                className="w-full flex items-center gap-3 px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg transition"
              >
                <span className="text-xl">{item.icon}</span>
                <span className="flex-1 text-left font-medium">{item.label}</span>
                <svg
                  className={`w-4 h-4 transition-transform ${expandedMenu === item.label ? 'rotate-180' : ''}`}
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
                </svg>
              </button>
            ) : (
              <Link
                to={item.href || '#'}
                className={`flex items-center gap-3 px-4 py-2 rounded-lg transition ${
                  location.pathname === item.href
                    ? 'bg-blue-100 text-blue-600 font-medium'
                    :  'text-gray-700 hover:bg-gray-100'
                }`}
              >
                <span className="text-xl">{item.icon}</span>
                <span className="font-medium">{item.label}</span>
              </Link>
            )}

            {/* Submenu */}
            {item.submenu && expandedMenu === item.label && (
              <div className="ml-6 mt-2 space-y-2 border-l-2 border-gray-200 pl-2">
                {item.submenu.map((subitem) => (
                  <Link
                    key={subitem. label}
                    to={subitem.href}
                    className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm transition ${
                      location.pathname === subitem.href
                        ? 'bg-blue-100 text-blue-600 font-medium'
                        : 'text-gray-600 hover:bg-gray-100'
                    }`}
                  >
                    <span>{subitem.icon}</span>
                    <span>{subitem. label}</span>
                  </Link>
                ))}
              </div>
            )}
          </div>
        ))}
      </nav>

      {/* Upgrade Section */}
      <div className="p-4 m-4 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg">
        <h3 className="font-semibold mb-2">Unlock Premium</h3>
        <p className="text-sm text-blue-100 mb-4">Get unlimited credits and advanced features</p>
        <Link
          to="/billing"
          className="block w-full text-center bg-white text-blue-600 font-semibold py-2 rounded hover:bg-gray-100 transition"
        >
          Upgrade Plan
        </Link>
      </div>
    </aside>
  )
}