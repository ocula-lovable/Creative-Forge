import { useEffect, useState } from 'react'
import { useAuth } from '../hooks/useAuth'
import { useProject } from '../hooks/useProject'
import { useApi } from '../hooks/useApi'
import { projectService } from '../services/project'
import { videoService } from '../services/video'
import { imageService } from '../services/image'
import { Link } from 'react-router-dom'

export default function Dashboard() {
  const { user } = useAuth()
  const { projects, setProjects } = useProject()
  const [videos, setVideos] = useState([])
  const [images, setImages] = useState([])
  const [stats, setStats] = useState({
    videos_count: 0,
    images_count: 0,
    avatars_count: 0,
  })

  const projectsApi = useApi(projectService. listProjects, { showSuccess: false, showError: false })
  const videosApi = useApi(videoService.listVideos, { showSuccess: false, showError: false })
  const imagesApi = useApi(imageService.listImages, { showSuccess: false, showError: false })

  useEffect(() => {
    loadData()
  }, [])

  const loadData = async () => {
    try {
      const [projectsList, videosList, imagesList] = await Promise.all([
        projectsApi.execute(0, 5),
        videosApi.execute(undefined, 0, 5),
        imagesApi.execute(undefined, 0, 5),
      ])

      setProjects(projectsList || [])
      setVideos(videosList || [])
      setImages(imagesList || [])

      setStats({
        videos_count:  videosList?.length || 0,
        images_count: imagesList?.length || 0,
        avatars_count: 0,
      })
    } catch (error) {
      console.error('Failed to load dashboard data:', error)
    }
  }

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Welcome, {user?.username}!</h1>
        <p className="text-gray-600 mt-2">Here's what you've been creating</p>
      </div>

      {/* Stats Cards */}
      <div className="grid md:grid-cols-4 gap-4 mb-8">
        <StatsCard label="Credits Available" value={user?.available_credits?. toFixed(1) || '100'} />
        <StatsCard label="Videos Created" value={stats.videos_count} />
        <StatsCard label="Images Created" value={stats.images_count} />
        <StatsCard label="Projects" value={projects.length} />
      </div>

      {/* Recent Projects */}
      <div className="bg-white rounded-lg shadow p-6 mb-8">
        <h2 className="text-2xl font-bold mb-4">Recent Projects</h2>
        {projects.length > 0 ? (
          <div className="grid md:grid-cols-3 gap-4">
            {projects.map(project => (
              <div key={project.id} className="border border-gray-200 rounded-lg p-4 hover:shadow-lg transition">
                <h3 className="font-semibold text-lg mb-2">{project.title}</h3>
                <p className="text-gray-600 text-sm mb-4">{project.description}</p>
                <Link to={`/projects/${project.id}`} className="text-blue-600 hover:underline text-sm font-semibold">
                  View Project
                </Link>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-gray-600">No projects yet.  Create one to get started!</p>
        )}
      </div>

      {/* Quick Actions */}
      <div className="grid md:grid-cols-3 gap-4">
        <QuickActionCard title="Create Video" icon="🎬" href="/videos/generator" />
        <QuickActionCard title="Generate Image" icon="🖼️" href="/images/generator" />
        <QuickActionCard title="Create Avatar" icon="👤" href="/avatars/studio" />
      </div>
    </div>
  )
}

function StatsCard({ label, value }: { label: string; value:  string | number }) {
  return (
    <div className="bg-white rounded-lg shadow p-6">
      <p className="text-gray-600 text-sm font-medium">{label}</p>
      <p className="text-3xl font-bold mt-2">{value}</p>
    </div>
  )
}

function QuickActionCard({ title, icon, href }: { title: string; icon: string; href: string }) {
  return (
    <Link
      to={href}
      className="bg-gradient-to-br from-blue-500 to-blue-600 text-white rounded-lg p-6 hover:shadow-lg transition cursor-pointer"
    >
      <div className="text-4xl mb-4">{icon}</div>
      <h3 className="text-xl font-semibold">{title}</h3>
    </Link>
  )
}