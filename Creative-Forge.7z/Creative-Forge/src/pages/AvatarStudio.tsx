import { useState, useEffect } from 'react'
import { useProject } from '../hooks/useProject'
import { useAuth } from '../hooks/useAuth'
import { useNotifications } from '../hooks/useNotifications'
import { useApi } from '../hooks/useApi'
import { avatarService } from '../services/avatar'
import { Link } from 'react-router-dom'

export default function AvatarStudio() {
  const { currentProject, projects } = useProject()
  const { user } = useAuth()
  const { addToast } = useNotifications()
  const [selectedProjectId, setSelectedProjectId] = useState(currentProject?.id || 0)
  const [voices, setVoices] = useState([])
  const [formData, setFormData] = useState({
    project_id: selectedProjectId,
    name: '',
    description: '',
    gender: 'female',
    ethnicity: 'asian',
    voice_id: '',
    voice_name: '',
    language: 'en',
  })

  const avatarApi = useApi(avatarService.createAvatar, { showSuccess: true, successMessage: 'Avatar created successfully!' })
  const voicesApi = useApi(avatarService.getVoices, { showSuccess: false })

  useEffect(() => {
    loadVoices()
  }, [])

  const loadVoices = async () => {
    try {
      await voicesApi.execute()
      if (voicesApi.data?. voices) {
        setVoices(voicesApi.data. voices)
      }
    } catch (error) {
      console.error('Failed to load voices:', error)
    }
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setFormData(prev => ({ ...prev, [name]: value }))
  }

  const handleProjectChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const projectId = parseInt(e.target.value)
    setSelectedProjectId(projectId)
    setFormData(prev => ({ ...prev, project_id: projectId }))
  }

  const handleVoiceChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const voice = voices.find(v => v.voice_id === e.target.value)
    if (voice) {
      setFormData(prev => ({
        ...prev,
        voice_id: voice.voice_id,
        voice_name: voice.name,
      }))
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!formData.project_id) {
      addToast('error', 'Please select a project')
      return
    }

    try {
      await avatarApi. execute(formData)
      setFormData({
        project_id: selectedProjectId,
        name: '',
        description: '',
        gender:  'female',
        ethnicity:  'asian',
        voice_id: '',
        voice_name: '',
        language: 'en',
      })
    } catch (error) {
      // Error handled by useApi hook
    }
  }

  return (
    <div className="p-8 max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold mb-8">Avatar Studio</h1>

      <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow-lg p-8 space-y-6">
        <div>
          <label className="block text-gray-700 font-semibold mb-2">Project</label>
          <select
            value={selectedProjectId}
            onChange={handleProjectChange}
            className="input-field"
            required
          >
            <option value={0}>Select a project...</option>
            {projects.map(project => (
              <option key={project.id} value={project.id}>
                {project.title}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-gray-700 font-semibold mb-2">Avatar Name</label>
          <input
            type="text"
            name="name"
            value={formData.name}
            onChange={handleChange}
            className="input-field"
            placeholder="e.g., Sarah, Alex, Jordan"
            required
          />
        </div>

        <div>
          <label className="block text-gray-700 font-semibold mb-2">Description</label>
          <textarea
            name="description"
            value={formData.description}
            onChange={handleChange}
            className="input-field h-24"
            placeholder="Optional:  Describe your avatar's characteristics"
          />
        </div>

        <div className="grid md:grid-cols-3 gap-4">
          <div>
            <label className="block text-gray-700 font-semibold mb-2">Gender</label>
            <select
              name="gender"
              value={formData.gender}
              onChange={handleChange}
              className="input-field"
            >
              <option value="male">Male</option>
              <option value="female">Female</option>
              <option value="non-binary">Non-binary</option>
            </select>
          </div>

          <div>
            <label className="block text-gray-700 font-semibold mb-2">Ethnicity</label>
            <select
              name="ethnicity"
              value={formData.ethnicity}
              onChange={handleChange}
              className="input-field"
            >
              <option value="asian">Asian</option>
              <option value="caucasian">Caucasian</option>
              <option value="african">African</option>
              <option value="hispanic">Hispanic</option>
              <option value="middle_eastern">Middle Eastern</option>
            </select>
          </div>

          <div>
            <label className="block text-gray-700 font-semibold mb-2">Language</label>
            <select
              name="language"
              value={formData.language}
              onChange={handleChange}
              className="input-field"
            >
              <option value="en">English</option>
              <option value="es">Spanish</option>
              <option value="fr">French</option>
              <option value="de">German</option>
              <option value="ja">Japanese</option>
            </select>
          </div>
        </div>

        <div>
          <label className="block text-gray-700 font-semibold mb-2">Voice</label>
          <select
            value={formData.voice_id}
            onChange={handleVoiceChange}
            className="input-field"
            required
          >
            <option value="">Select a voice... </option>
            {voices.map((voice:  any) => (
              <option key={voice.voice_id} value={voice.voice_id}>
                {voice.name} ({voice.accent})
              </option>
            ))}
          </select>
        </div>

        <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
          <p className="text-sm text-gray-700">
            <strong>Avatar Videos Cost:</strong> 15 credits per video
          </p>
        </div>

        <button
          type="submit"
          disabled={avatarApi.isLoading || !formData.project_id}
          className="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition"
        >
          {avatarApi.isLoading ? (
            <span className="flex items-center justify-center gap-2">
              <span className="loading-spinner"></span>
              Creating Avatar...
            </span>
          ) : (
            'Create Avatar'
          )}
        </button>
      </form>
    </div>
  )
}