import { useEffect, useState } from 'react'
import { useProject } from '../hooks/useProject'
import { useApi } from '../hooks/useApi'
import { useNotifications } from '../hooks/useNotifications'
import { projectService } from '../services/project'
import { Link } from 'react-router-dom'

export default function Projects() {
  const { projects, setProjects, setCurrentProject } = useProject()
  const { addToast } = useNotifications()
  const [showNewProjectForm, setShowNewProjectForm] = useState(false)
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    category: 'video',
  })

  const projectsApi = useApi(projectService. listProjects, { showSuccess: false })
  const createApi = useApi(projectService.createProject, { showSuccess: true, successMessage: 'Project created!' })

  useEffect(() => {
    loadProjects()
  }, [])

  const loadProjects = async () => {
    try {
      const data = await projectsApi.execute(0, 100)
      setProjects(data || [])
    } catch (error) {
      addToast('error', 'Failed to load projects')
    }
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setFormData(prev => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e: React. FormEvent) => {
    e.preventDefault()

    try {
      const newProject = await createApi.execute(formData)
      setProjects([newProject, ...projects])
      setFormData({ title: '', description: '', category: 'video' })
      setShowNewProjectForm(false)
    } catch (error) {
      // Error handled by useApi hook
    }
  }

  const handleSelectProject = (project: any) => {
    setCurrentProject(project)
  }

  return (
    <div className="p-8">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">Projects</h1>
        <button
          onClick={() => setShowNewProjectForm(! showNewProjectForm)}
          className="bg-blue-600 text-white px-6 py-2 rounded-lg font-semibold hover:bg-blue-700 transition"
        >
          + New Project
        </button>
      </div>

      {showNewProjectForm && (
        <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow-lg p-6 mb-8 space-y-4">
          <div>
            <label className="block text-gray-700 font-semibold mb-2">Project Title</label>
            <input
              type="text"
              name="title"
              value={formData. title}
              onChange={handleChange}
              className="input-field"
              placeholder="e.g., Q4 Product Campaign"
              required
            />
          </div>

          <div>
            <label className="block text-gray-700 font-semibold mb-2">Description</label>
            <input
              type="text"
              name="description"
              value={formData.description}
              onChange={handleChange}
              className="input-field"
              placeholder="Optional project description"
            />
          </div>

          <div>
            <label className="block text-gray-700 font-semibold mb-2">Category</label>
            <select
              name="category"
              value={formData.category}
              onChange={handleChange}
              className="input-field"
            >
              <option value="video">Video</option>
              <option value="image">Image</option>
              <option value="ad">Advertisement</option>
              <option value="mixed">Mixed Media</option>
            </select>
          </div>

          <div className="flex gap-4">
            <button
              type="submit"
              disabled={createApi.isLoading}
              className="flex-1 bg-blue-600 text-white py-2 rounded-lg font-semibold hover:bg-blue-700 disabled:opacity-50 transition"
            >
              {createApi.isLoading ? 'Creating...' : 'Create Project'}
            </button>
            <button
              type="button"
              onClick={() => setShowNewProjectForm(false)}
              className="flex-1 bg-gray-600 text-white py-2 rounded-lg font-semibold hover:bg-gray-700 transition"
            >
              Cancel
            </button>
          </div>
        </form>
      )}

      {projects.length > 0 ?  (
        <div className="grid md:grid-cols-3 gap-6">
          {projects.map(project => (
            <div
              key={project.id}
              onClick={() => handleSelectProject(project)}
              className="bg-white rounded-lg shadow p-6 hover:shadow-lg transition cursor-pointer"
            >
              {project.thumbnail_url && (
                <img
                  src={project.thumbnail_url}
                  alt={project.title}
                  className="w-full h-40 object-cover rounded-lg mb-4"
                />
              )}
              <h3 className="text-xl font-bold mb-2">{project.title}</h3>
              <p className="text-gray-600 text-sm mb-4">{project.description}</p>
              <div className="flex items-center justify-between">
                <span className={`px-3 py-1 rounded-full text-sm font-semibold ${
                  project.status === 'draft'
                    ? 'bg-yellow-100 text-yellow-800'
                    : 'bg-green-100 text-green-800'
                }`}>
                  {project.status}
                </span>
                <Link
                  to={`/projects/${project.id}`}
                  className="text-blue-600 hover:text-blue-800 font-semibold"
                >
                  View →
                </Link>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-12">
          <p className="text-gray-600 text-lg mb-4">No projects yet</p>
          <button
            onClick={() => setShowNewProjectForm(true)}
            className="bg-blue-600 text-white px-6 py-2 rounded-lg font-semibold hover:bg-blue-700 transition"
          >
            Create Your First Project
          </button>
        </div>
      )}
    </div>
  )
}