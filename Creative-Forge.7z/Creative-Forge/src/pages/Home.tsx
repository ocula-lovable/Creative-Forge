import { Link } from 'react-router-dom'
import { useAuth } from '../hooks/useAuth'

export default function Home() {
  const { isAuthenticated } = useAuth()

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-600 to-purple-600">
      {/* Navigation */}
      <nav className="bg-white bg-opacity-10 backdrop-blur-md">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold text-white">Creative Forge</h1>
          <div className="flex gap-4">
            {isAuthenticated ? (
              <Link to="/dashboard" className="bg-white text-blue-600 px-6 py-2 rounded-lg font-semibold hover:bg-gray-100 transition">
                Dashboard
              </Link>
            ) : (
              <>
                <Link to="/login" className="text-white hover:bg-white hover:bg-opacity-20 px-6 py-2 rounded-lg transition">
                  Login
                </Link>
                <Link to="/signup" className="bg-white text-blue-600 px-6 py-2 rounded-lg font-semibold hover:bg-gray-100 transition">
                  Sign Up
                </Link>
              </>
            )}
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-20 text-center">
        <h2 className="text-5xl font-bold text-white mb-6">
          Create AI-Powered Content in Minutes
        </h2>
        <p className="text-xl text-white text-opacity-90 mb-8 max-w-2xl mx-auto">
          Generate stunning videos, images, and ads using artificial intelligence. No technical skills required.
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16">
          {! isAuthenticated && (
            <>
              <Link
                to="/signup"
                className="bg-white text-blue-600 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition"
              >
                Get Started Free
              </Link>
              <Link
                to="/pricing"
                className="bg-blue-500 text-white px-8 py-3 rounded-lg font-semibold hover:bg-blue-700 transition"
              >
                View Pricing
              </Link>
            </>
          )}
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-3 gap-8 mt-20">
          {[
            {
              title: 'Video Generation',
              description: 'Create professional videos from simple text prompts',
              icon: '🎬',
            },
            {
              title:  'AI Images',
              description: 'Generate stunning images for any purpose',
              icon: '🖼️',
            },
            {
              title: 'Avatar Creation',
              description: 'Create talking head videos with AI avatars',
              icon: '👤',
            },
            {
              title: 'Ad Templates',
              description: 'Platform-specific templates for social media ads',
              icon: '📱',
            },
            {
              title: 'Video Editing',
              description: 'Professional timeline-based video editor',
              icon: '✂️',
            },
            {
              title: 'Export & Share',
              description: 'Export in multiple formats and share instantly',
              icon: '📤',
            },
          ]. map((feature, index) => (
            <div
              key={index}
              className="bg-white bg-opacity-10 backdrop-blur-md rounded-lg p-6 text-white hover:bg-opacity-20 transition"
            >
              <div className="text-4xl mb-4">{feature.icon}</div>
              <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
              <p className="text-white text-opacity-80">{feature.description}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-white border-opacity-20 mt-20">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 text-white text-center text-opacity-80">
          <p>&copy; 2024 Creative Forge. All rights reserved. </p>
        </div>
      </footer>
    </div>
  )
}