import { useState } from 'react'
import { useProject } from '../hooks/useProject'
import { useAuth } from '../hooks/useAuth'
import { useNotifications } from '../hooks/useNotifications'
import { useApi } from '../hooks/useApi'
import { imageService } from '../services/image'
import { Link } from 'react-router-dom'

export default function ImageGenerator() {
  const { currentProject, projects } = useProject()
  const { user } = useAuth()
  const { addToast } = useNotifications()
  const [selectedProjectId, setSelectedProjectId] = useState(currentProject?.id || 0)
  const [formData, setFormData] = useState({
    project_id: selectedProjectId,
    title: '',
    description: '',
    prompt: '',
    image_type: 'custom',
    style: 'realistic',
  })

  const imageApi = useApi(imageService.createImage, { showSuccess: true, successMessage: 'Image generation started!' })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setFormData(prev => ({ ...prev, [name]: value }))
  }

  const handleProjectChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const projectId = parseInt(e.target.value)
    setSelectedProjectId(projectId)
    setFormData(prev => ({ ...prev, project_id: projectId }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!formData.project_id) {
      addToast('error', 'Please select a project')
      return
    }

    if ((user?.available_credits || 0) < 2) {
      addToast('error', 'Insufficient credits.  Please upgrade your plan.')
      return
    }

    try {
      await imageApi.execute(formData)
      setFormData({ project_id: selectedProjectId, title: '', description: '', prompt:  '', image_type: 'custom', style: 'realistic' })
    } catch (error) {
      // Error handled by useApi hook
    }
  }

  return (
    <div className="p-8 max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold mb-8">Generate Image</h1>

      <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow-lg p-8 space-y-6">
        <div>
          <label className="block text-gray-700 font-semibold mb-2">Project</label>
          <select
            value={selectedProjectId}
            onChange={handleProjectChange}
            className="input-field"
            required
          >
            <option value={0}>Select a project...</option>
            {projects.map(project => (
              <option key={project.id} value={project. id}>
                {project.title}
              </option>
            ))}
          </select>
          {projects.length === 0 && (
            <p className="text-sm text-gray-600 mt-2">
              No projects yet. <Link to="/projects" className="text-blue-600 hover:underline">Create one first</Link>
            </p>
          )}
        </div>

        <div>
          <label className="block text-gray-700 font-semibold mb-2">Image Title</label>
          <input
            type="text"
            name="title"
            value={formData.title}
            onChange={handleChange}
            className="input-field"
            placeholder="e. g., Product Hero Image"
            required
          />
        </div>

        <div>
          <label className="block text-gray-700 font-semibold mb-2">Image Prompt</label>
          <textarea
            name="prompt"
            value={formData.prompt}
            onChange={handleChange}
            placeholder="Describe the image you want to generate in detail..."
            className="input-field h-32"
            required
          />
          <p className="text-xs text-gray-500 mt-2">
            Tips:  Include details like subject, composition, lighting, colors, and mood.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-4">
          <div>
            <label className="block text-gray-700 font-semibold mb-2">Style</label>
            <select
              name="style"
              value={formData.style}
              onChange={handleChange}
              className="input-field"
            >
              <option value="realistic">Realistic</option>
              <option value="3d">3D Render</option>
              <option value="anime">Anime</option>
              <option value="illustration">Illustration</option>
              <option value="cartoon">Cartoon</option>
              <option value="watercolor">Watercolor</option>
              <option value="oil_painting">Oil Painting</option>
            </select>
          </div>

          <div>
            <label className="block text-gray-700 font-semibold mb-2">Image Type</label>
            <select
              name="image_type"
              value={formData.image_type}
              onChange={handleChange}
              className="input-field"
            >
              <option value="custom">Custom</option>
              <option value="ad">Advertisement</option>
              <option value="poster">Poster</option>
              <option value="thumbnail">Thumbnail</option>
              <option value="character">Character</option>
              <option value="product">Product</option>
            </select>
          </div>

          <div>
            <label className="block text-gray-700 font-semibold mb-2">Resolution</label>
            <select className="input-field">
              <option>512x512</option>
              <option selected>1024x1024</option>
              <option>1280x1280</option>
            </select>
          </div>
        </div>

        <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
          <p className="text-sm text-gray-700 mb-2">
            <strong>Credits Cost:</strong> 2 credits per image
          </p>
          <p className="text-sm text-gray-700">
            <strong>Available Credits: </strong> <span className={user?. available_credits! < 2 ? 'text-red-600 font-bold' : ''}>{(user?.available_credits || 0).toFixed(1)}</span>
          </p>
        </div>

        <button
          type="submit"
          disabled={imageApi.isLoading || !formData.project_id}
          className="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition"
        >
          {imageApi.isLoading ? (
            <span className="flex items-center justify-center gap-2">
              <span className="loading-spinner"></span>
              Generating Image... 
            </span>
          ) : (
            'Generate Image'
          )}
        </button>
      </form>
    </div>
  )
}