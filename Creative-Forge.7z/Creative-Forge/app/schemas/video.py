from pydantic import BaseModel
from typing import Optional
from datetime import datetime

class VideoBase(BaseModel):
    title: str
    description:  Optional[str] = None
    prompt: str
    video_type: str = "custom"

class VideoCreate(VideoBase):
    project_id: int

class VideoUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    script: Optional[str] = None

class VideoResponse(VideoBase):
    id: int
    project_id: int
    status: str
    video_url: Optional[str] = None
    thumbnail_url: Optional[str] = None
    duration_seconds: Optional[float] = None
    credits_used: float
    created_at:  datetime
    updated_at: datetime
    
    class Config: 
        from_attributes = True

class VideoDetailResponse(VideoResponse):
    script: Optional[str] = None
    resolution: str
    format: str
    file_size_mb: Optional[float] = None
    model_used: Optional[str] = None
    error_message: Optional[str] = None
    completed_at: Optional[datetime] = None