from pydantic import BaseModel
from typing import Optional
from datetime import datetime

class AvatarBase(BaseModel):
    name: str
    description: Optional[str] = None
    gender: Optional[str] = None
    ethnicity: Optional[str] = None
    age_range: Optional[str] = None

class AvatarCreate(AvatarBase):
    project_id: int
    voice_id: Optional[str] = None
    voice_name: Optional[str] = None
    language: str = "en"
    accent:  Optional[str] = None

class AvatarUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    voice_id: Optional[str] = None
    language: Optional[str] = None

class AvatarResponse(AvatarBase):
    id: int
    project_id: int
    status: str
    avatar_url: Optional[str] = None
    voice_name: Optional[str] = None
    language: str
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True

class AvatarVideoRequest(BaseModel):
    avatar_id: int
    script: str
    voice_id: Optional[str] = None