from pydantic import BaseModel, EmailStr, Field
from typing import Optional
from datetime import datetime

class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int

class LoginRequest(BaseModel):
    email: EmailStr
    password: str = Field(..., min_length=6)

class SignupRequest(BaseModel):
    email: EmailStr
    username: str = Field(..., min_length=3, max_length=255)
    password: str = Field(..., min_length=6)
    full_name: Optional[str] = None

class RefreshTokenRequest(BaseModel):
    refresh_token: str

class ResetPasswordRequest(BaseModel):
    email: EmailStr

class ConfirmPasswordReset(BaseModel):
    token: str
    password: str = Field(..., min_length=6)