from pydantic import BaseModel
from typing import Optional
from datetime import datetime

class ImageBase(BaseModel):
    title: str
    description: Optional[str] = None
    prompt: str
    image_type: str = "custom"
    style: Optional[str] = None

class ImageCreate(ImageBase):
    project_id: int

class ImageUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None

class ImageResponse(ImageBase):
    id: int
    project_id: int
    status: str
    image_url: Optional[str] = None
    resolution: str
    credits_used: float
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True