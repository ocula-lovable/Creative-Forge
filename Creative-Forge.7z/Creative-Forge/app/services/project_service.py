from sqlalchemy.orm import Session
from sqlalchemy import desc
from app.models.project import Project, ProjectStatus
from app.schemas.project import ProjectCreate, ProjectUpdate
from app.core.logging import get_logger
from datetime import datetime

logger = get_logger(__name__)

class ProjectService:
    @staticmethod
    def create_project(db: Session, user_id: int, project_data: ProjectCreate) -> Project:
        """Create a new project."""
        project = Project(
            user_id=user_id,
            title=project_data.title,
            description=project_data.description,
            category=project_data.category,
            status=ProjectStatus.DRAFT
        )
        
        db.add(project)
        db.commit()
        db.refresh(project)
        
        logger.info(f"Project created: {project.id} for user {user_id}")
        return project
    
    @staticmethod
    def get_project_by_id(db: Session, project_id: int, user_id: int) -> Project:
        """Get project by ID (user-specific)."""
        return db. query(Project).filter(
            Project.id == project_id,
            Project.user_id == user_id
        ).first()
    
    @staticmethod
    def list_projects(db: Session, user_id: int, skip: int = 0, limit: int = 20) -> list:
        """List all projects for a user."""
        return db.query(Project).filter(
            Project.user_id == user_id
        ).order_by(desc(Project.created_at)).offset(skip).limit(limit).all()
    
    @staticmethod
    def update_project(db: Session, project_id: int, user_id: int, update_data: ProjectUpdate) -> Project:
        """Update a project."""
        project = ProjectService.get_project_by_id(db, project_id, user_id)
        
        if not project:
            raise ValueError("Project not found")
        
        update_dict = update_data.dict(exclude_unset=True)
        for field, value in update_dict.items():
            setattr(project, field, value)
        
        project.updated_at = datetime.utcnow()
        db.add(project)
        db.commit()
        db.refresh(project)
        
        logger.info(f"Project updated: {project.id}")
        return project
    
    @staticmethod
    def delete_project(db: Session, project_id: int, user_id: int) -> bool:
        """Delete a project."""
        project = ProjectService.get_project_by_id(db, project_id, user_id)
        
        if not project:
            raise ValueError("Project not found")
        
        db.delete(project)
        db.commit()
        
        logger.info(f"Project deleted: {project. id}")
        return True
    
    @staticmethod
    def get_project_stats(db:  Session, project_id: int, user_id: int) -> dict:
        """Get project statistics."""
        project = ProjectService.get_project_by_id(db, project_id, user_id)
        
        if not project:
            raise ValueError("Project not found")
        
        total_credits = sum(v.credits_used for v in project.videos) + \
                       sum(i.credits_used for i in project.images) + \
                       sum(a.credits_used for a in project.avatars)
        
        return {
            "videos_count": len(project.videos),
            "images_count": len(project.images),
            "avatars_count": len(project.avatars),
            "assets_count": len(project.assets),
            "total_credits_used": total_credits,
        }