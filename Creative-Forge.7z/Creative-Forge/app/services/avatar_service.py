from sqlalchemy.orm import Session
from sqlalchemy import desc
from app.models.avatar import Avatar, AvatarStatus
from app.schemas.avatar import AvatarCreate, AvatarUpdate, AvatarVideoRequest
from app.services.user_service import UserService
from app.core.logging import get_logger
from datetime import datetime

logger = get_logger(__name__)

class AvatarService:
    CREDIT_COST = 15.0  # Per avatar video
    
    @staticmethod
    def create_avatar(db:  Session, user_id: int, avatar_data: AvatarCreate) -> Avatar:
        """Create a new avatar."""
        avatar = Avatar(
            user_id=user_id,
            project_id=avatar_data.project_id,
            name=avatar_data.name,
            description=avatar_data.description,
            gender=avatar_data.gender,
            ethnicity=avatar_data.ethnicity,
            voice_id=avatar_data.voice_id,
            voice_name=avatar_data.voice_name,
            language=avatar_data.language,
            accent=avatar_data.accent,
            status=AvatarStatus.COMPLETED,  # Avatar setup is instant
        )
        
        db.add(avatar)
        db.commit()
        db.refresh(avatar)
        
        logger.info(f"Avatar created: {avatar.id} for user {user_id}")
        return avatar
    
    @staticmethod
    def get_avatar_by_id(db: Session, avatar_id:  int, user_id: int) -> Avatar:
        """Get avatar by ID."""
        return db. query(Avatar).filter(
            Avatar.id == avatar_id,
            Avatar.user_id == user_id
        ).first()
    
    @staticmethod
    def list_avatars(db: Session, user_id: int, project_id: int = None, skip: int = 0, limit: int = 20) -> list:
        """List avatars for a user."""
        query = db.query(Avatar).filter(Avatar.user_id == user_id)
        
        if project_id:
            query = query.filter(Avatar.project_id == project_id)
        
        return query.order_by(desc(Avatar.created_at)).offset(skip).limit(limit).all()
    
    @staticmethod
    def update_avatar(db: Session, avatar_id:  int, user_id: int, update_data: AvatarUpdate) -> Avatar:
        """Update avatar."""
        avatar = AvatarService.get_avatar_by_id(db, avatar_id, user_id)
        
        if not avatar:
            raise ValueError("Avatar not found")
        
        update_dict = update_data. dict(exclude_unset=True)
        for field, value in update_dict.items():
            setattr(avatar, field, value)
        
        avatar.updated_at = datetime.utcnow()
        db.add(avatar)
        db.commit()
        db.refresh(avatar)
        
        return avatar
    
    @staticmethod
    def delete_avatar(db: Session, avatar_id: int, user_id: int) -> bool:
        """Delete an avatar."""
        avatar = AvatarService.get_avatar_by_id(db, avatar_id, user_id)
        
        if not avatar: 
            raise ValueError("Avatar not found")
        
        db.delete(avatar)
        db.commit()
        
        logger.info(f"Avatar deleted: {avatar_id}")
        return True
    
    @staticmethod
    def generate_avatar_video(db: Session, user_id: int, avatar_id: int, script: str, voice_id: str = None) -> dict:
        """Generate a talking head video from avatar."""
        # Check credits
        user_credits = UserService.get_user_credits(db, user_id)
        
        if user_credits < AvatarService.CREDIT_COST:
            raise ValueError("Insufficient credits")
        
        # Get avatar
        avatar = AvatarService.get_avatar_by_id(db, avatar_id, user_id)
        if not avatar:
            raise ValueError("Avatar not found")
        
        # Store script
        avatar.latest_script = script
        
        # Deduct credits
        UserService. deduct_credits(db, user_id, AvatarService. CREDIT_COST)
        
        db.add(avatar)
        db.commit()
        
        # Return job info (will be picked up by background task)
        return {
            "avatar_id": avatar.id,
            "script": script,
            "voice_id": voice_id or avatar.voice_id,
            "language": avatar.language,
        }
    
    @staticmethod
    def update_avatar_video(db: Session, avatar_id:  int, video_url: str) -> Avatar:
        """Update avatar with generated video."""
        avatar = db.query(Avatar).filter(Avatar.id == avatar_id).first()
        
        if not avatar:
            raise ValueError("Avatar not found")
        
        avatar. latest_video_url = video_url
        avatar.status = AvatarStatus.COMPLETED
        avatar.updated_at = datetime.utcnow()
        
        db.add(avatar)
        db.commit()
        db.refresh(avatar)
        
        return avatar