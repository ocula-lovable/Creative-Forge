from sqlalchemy.orm import Session
from datetime import datetime, timedelta
from app.models.user import User
from app. core.security import (
    hash_password,
    verify_password,
    create_access_token,
    create_refresh_token,
    decode_token
)
from app.schemas.auth import LoginRequest, SignupRequest
from app.core.config import settings
from app. core.logging import get_logger

logger = get_logger(__name__)

class AuthService:
    @staticmethod
    def register_user(db: Session, signup_data: SignupRequest) -> User:
        """Register a new user."""
        # Check if user exists
        existing_user = db. query(User).filter(
            (User.email == signup_data. email) | 
            (User.username == signup_data.username)
        ).first()
        
        if existing_user:
            raise ValueError("Email or username already exists")
        
        # Hash password
        hashed_password = hash_password(signup_data.password)
        
        # Create user
        user = User(
            email=signup_data.email,
            username=signup_data. username,
            hashed_password=hashed_password,
            full_name=signup_data.full_name,
            available_credits=100. 0,  # Free credits
        )
        
        db.add(user)
        db.commit()
        db.refresh(user)
        
        logger.info(f"User registered: {user.email}")
        return user
    
    @staticmethod
    def authenticate_user(db: Session, email: str, password: str) -> User:
        """Authenticate a user."""
        user = db.query(User).filter(User.email == email).first()
        
        if not user or not verify_password(password, user.hashed_password):
            raise ValueError("Invalid credentials")
        
        if not user.is_active:
            raise ValueError("User account is inactive")
        
        # Update last login
        user.last_login_at = datetime.utcnow()
        db.add(user)
        db.commit()
        
        logger.info(f"User authenticated: {user.email}")
        return user
    
    @staticmethod
    def create_tokens(user_id: int) -> dict:
        """Create access and refresh tokens."""
        access_token = create_access_token({"sub": user_id})
        refresh_token = create_refresh_token({"sub": user_id})
        
        return {
            "access_token": access_token,
            "refresh_token": refresh_token,
            "token_type": "bearer",
            "expires_in": settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60
        }
    
    @staticmethod
    def refresh_access_token(refresh_token: str) -> str:
        """Refresh an access token."""
        payload = decode_token(refresh_token)
        
        if not payload or payload.get("type") != "refresh":
            raise ValueError("Invalid refresh token")
        
        user_id = payload.get("sub")
        return create_access_token({"sub": user_id})
    
    @staticmethod
    def verify_user_exists(db: Session, user_id: int) -> bool:
        """Verify user exists."""
        user = db.query(User).filter(User.id == user_id).first()
        return user is not None