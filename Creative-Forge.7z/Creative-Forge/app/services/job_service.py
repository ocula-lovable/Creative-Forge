from sqlalchemy.orm import Session
from sqlalchemy import desc
from app.models. job import Job, JobStatus, JobType
from app.core.logging import get_logger
from datetime import datetime
import uuid

logger = get_logger(__name__)

class JobService:
    @staticmethod
    def create_job(db: Session, user_id: int, project_id: int, job_type: JobType,
                  video_id: int = None, image_id: int = None, avatar_id: int = None) -> Job:
        """Create a new job."""
        job_id = str(uuid.uuid4())
        
        job = Job(
            job_id=job_id,
            project_id=project_id,
            user_id=user_id,
            job_type=job_type,
            status=JobStatus.QUEUED,
            video_id=video_id,
            image_id=image_id,
            avatar_id=avatar_id,
        )
        
        db.add(job)
        db.commit()
        db.refresh(job)
        
        logger.info(f"Job created: {job.id} - {job_type}")
        return job
    
    @staticmethod
    def get_job_by_id(db: Session, job_id: int) -> Job:
        """Get job by ID."""
        return db.query(Job).filter(Job.id == job_id).first()
    
    @staticmethod
    def get_job_by_external_id(db: Session, external_job_id: str) -> Job:
        """Get job by external job ID."""
        return db.query(Job).filter(Job.job_id == external_job_id).first()
    
    @staticmethod
    def list_jobs(db: Session, user_id: int, skip: int = 0, limit:  int = 20) -> list:
        """List user's jobs."""
        return db.query(Job).filter(
            Job.user_id == user_id
        ).order_by(desc(Job.created_at)).offset(skip).limit(limit).all()
    
    @staticmethod
    def update_job_status(db: Session, job_id: int, status: JobStatus,
                         progress: int = None, error_message: str = None, current_step: str = None) -> Job:
        """Update job status."""
        job = JobService.get_job_by_id(db, job_id)
        
        if not job: 
            raise ValueError("Job not found")
        
        job.status = status
        
        if progress is not None: 
            job.progress_percentage = progress
        
        if error_message:
            job.error_message = error_message
        
        if current_step: 
            job.current_step = current_step
        
        if status == JobStatus.COMPLETED: 
            job.completed_at = datetime.utcnow()
        elif status == JobStatus.PROCESSING:
            if not job.started_at:
                job.started_at = datetime.utcnow()
        
        db. add(job)
        db.commit()
        db.refresh(job)
        
        logger. info(f"Job updated:  {job.id} - {status}")
        return job
    
    @staticmethod
    def retry_job(db: Session, job_id: int) -> Job:
        """Retry a failed job."""
        job = JobService. get_job_by_id(db, job_id)
        
        if not job:
            raise ValueError("Job not found")
        
        if job.retry_count >= job.max_retries:
            raise ValueError("Max retries exceeded")
        
        job.retry_count += 1
        job.status = JobStatus.QUEUED
        job.error_message = None
        
        db.add(job)
        db.commit()
        db.refresh(job)
        
        logger.info(f"Job retried: {job.id} (attempt {job.retry_count})")
        return job
    
    @staticmethod
    def cancel_job(db: Session, job_id: int) -> Job:
        """Cancel a job."""
        job = JobService.get_job_by_id(db, job_id)
        
        if not job:
            raise ValueError("Job not found")
        
        if job.status in [JobStatus.COMPLETED, JobStatus.FAILED, JobStatus.CANCELLED]:
            raise ValueError("Cannot cancel completed job")
        
        job.status = JobStatus.CANCELLED
        db.add(job)
        db.commit()
        db.refresh(job)
        
        logger.info(f"Job cancelled: {job.id}")
        return job