from sqlalchemy.orm import Session
from sqlalchemy import desc
from app.models.video import Video, VideoStatus, VideoType
from app.models.job import Job, JobStatus, JobType
from app.schemas. video import VideoCreate, VideoUpdate
from app.core.logging import get_logger
from app.core.config import settings
from app.services.user_service import UserService
from datetime import datetime
import json

logger = get_logger(__name__)

class VideoService:
    # Credit costs for different durations
    CREDIT_COST_PER_MINUTE = 5.0
    
    @staticmethod
    def create_video(db: Session, user_id: int, video_data: VideoCreate) -> Video:
        """Create a new video generation request."""
        # Check credits
        user_credits = UserService.get_user_credits(db, user_id)
        estimated_credits = VideoService. CREDIT_COST_PER_MINUTE
        
        if user_credits < estimated_credits:
            raise ValueError("Insufficient credits")
        
        # Create video record
        video = Video(
            user_id=user_id,
            project_id=video_data.project_id,
            title=video_data.title,
            description=video_data.description,
            prompt=video_data.prompt,
            video_type=VideoType(video_data.video_type),
            status=VideoStatus.PENDING,
            credits_used=estimated_credits,
        )
        
        db.add(video)
        db.flush()
        
        # Deduct credits
        UserService.deduct_credits(db, user_id, estimated_credits)
        
        db.commit()
        db.refresh(video)
        
        logger.info(f"Video created: {video.id} for user {user_id}")
        return video
    
    @staticmethod
    def get_video_by_id(db: Session, video_id: int, user_id: int) -> Video:
        """Get video by ID."""
        return db.query(Video).filter(
            Video.id == video_id,
            Video.user_id == user_id
        ).first()
    
    @staticmethod
    def list_videos(db: Session, user_id: int, project_id: int = None, skip: int = 0, limit: int = 20) -> list:
        """List videos for a user."""
        query = db.query(Video).filter(Video.user_id == user_id)
        
        if project_id:
            query = query. filter(Video.project_id == project_id)
        
        return query.order_by(desc(Video.created_at)).offset(skip).limit(limit).all()
    
    @staticmethod
    def update_video(db: Session, video_id: int, user_id: int, update_data: VideoUpdate) -> Video:
        """Update video metadata."""
        video = VideoService. get_video_by_id(db, video_id, user_id)
        
        if not video:
            raise ValueError("Video not found")
        
        update_dict = update_data.dict(exclude_unset=True)
        for field, value in update_dict.items():
            setattr(video, field, value)
        
        video.updated_at = datetime.utcnow()
        db.add(video)
        db.commit()
        db.refresh(video)
        
        return video
    
    @staticmethod
    def update_video_status(db: Session, video_id: int, status: VideoStatus,
                           error_message: str = None, video_url: str = None) -> Video:
        """Update video processing status."""
        video = db.query(Video).filter(Video.id == video_id).first()
        
        if not video:
            raise ValueError("Video not found")
        
        video. status = status
        
        if error_message:
            video.error_message = error_message
        
        if video_url:
            video.video_url = video_url
        
        if status == VideoStatus.COMPLETED: 
            video.completed_at = datetime.utcnow()
        
        video.updated_at = datetime.utcnow()
        db.add(video)
        db.commit()
        db.refresh(video)
        
        return video
    
    @staticmethod
    def delete_video(db: Session, video_id: int, user_id: int) -> bool:
        """Delete a video."""
        video = VideoService. get_video_by_id(db, video_id, user_id)
        
        if not video:
            raise ValueError("Video not found")
        
        # Refund credits if failed
        if video.status in [VideoStatus.FAILED, VideoStatus.PENDING]: 
            UserService.add_credits(db, user_id, video.credits_used)
        
        db.delete(video)
        db.commit()
        
        logger.info(f"Video deleted: {video_id}")
        return True