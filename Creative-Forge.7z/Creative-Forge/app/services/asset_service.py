from sqlalchemy.orm import Session
from sqlalchemy import desc
from app.models. asset import Asset, AssetType
from app.core.logging import get_logger
from datetime import datetime

logger = get_logger(__name__)

class AssetService:
    @staticmethod
    def create_asset(db:  Session, user_id: int, project_id: int, 
                    name: str, asset_type: str, file_url: str, **kwargs) -> Asset:
        """Create a new asset."""
        asset = Asset(
            user_id=user_id,
            project_id=project_id,
            name=name,
            asset_type=AssetType(asset_type),
            file_url=file_url,
            file_size_mb=kwargs.get("file_size_mb"),
            duration_seconds=kwargs.get("duration_seconds"),
            format=kwargs.get("format"),
            resolution=kwargs.get("resolution"),
            tags=kwargs.get("tags"),
            description=kwargs.get("description"),
        )
        
        db.add(asset)
        db.commit()
        db.refresh(asset)
        
        logger.info(f"Asset created: {asset.id} for user {user_id}")
        return asset
    
    @staticmethod
    def get_asset_by_id(db: Session, asset_id:  int, user_id: int) -> Asset:
        """Get asset by ID."""
        return db. query(Asset).filter(
            Asset.id == asset_id,
            Asset.user_id == user_id
        ).first()
    
    @staticmethod
    def list_assets(db:  Session, user_id: int, project_id: int = None, 
                   asset_type: str = None, skip: int = 0, limit:  int = 20) -> list:
        """List assets for a user."""
        query = db.query(Asset).filter(Asset.user_id == user_id)
        
        if project_id: 
            query = query.filter(Asset.project_id == project_id)
        
        if asset_type:
            query = query.filter(Asset.asset_type == AssetType(asset_type))
        
        return query.order_by(desc(Asset.created_at)).offset(skip).limit(limit).all()
    
    @staticmethod
    def update_asset(db: Session, asset_id: int, user_id:  int, update_data: dict) -> Asset:
        """Update an asset."""
        asset = AssetService.get_asset_by_id(db, asset_id, user_id)
        
        if not asset:
            raise ValueError("Asset not found")
        
        for field, value in update_data. items():
            setattr(asset, field, value)
        
        asset.updated_at = datetime.utcnow()
        db.add(asset)
        db.commit()
        db.refresh(asset)
        
        return asset
    
    @staticmethod
    def delete_asset(db: Session, asset_id:  int, user_id: int) -> bool:
        """Delete an asset."""
        asset = AssetService.get_asset_by_id(db, asset_id, user_id)
        
        if not asset:
            raise ValueError("Asset not found")
        
        db.delete(asset)
        db.commit()
        
        logger.info(f"Asset deleted: {asset_id}")
        return True