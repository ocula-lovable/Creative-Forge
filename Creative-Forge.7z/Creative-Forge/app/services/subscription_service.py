from sqlalchemy.orm import Session
from datetime import datetime, timedelta
from app.models. subscription import Subscription, Plan, SubscriptionStatus, PlanType
from app.models.user import User
from app. core.logging import get_logger

logger = get_logger(__name__)

class SubscriptionService: 
    @staticmethod
    def create_subscription(db: Session, user_id: int, plan_type: PlanType, 
                          billing_cycle: str = "monthly") -> Subscription:
        """Create a new subscription."""
        # Get plan
        plan = db.query(Plan).filter(Plan.plan_type == plan_type).first()
        
        if not plan:
            raise ValueError("Plan not found")
        
        # Calculate period dates
        now = datetime.utcnow()
        if billing_cycle == "monthly": 
            period_end = now + timedelta(days=30)
        else:  # yearly
            period_end = now + timedelta(days=365)
        
        # Create subscription
        subscription = Subscription(
            user_id=user_id,
            plan_id=plan.id,
            status=SubscriptionStatus.ACTIVE,
            billing_cycle=billing_cycle,
            current_period_start=now,
            current_period_end=period_end,
        )
        
        db.add(subscription)
        db.commit()
        db.refresh(subscription)
        
        logger.info(f"Subscription created for user {user_id}:  {plan_type}")
        return subscription
    
    @staticmethod
    def get_user_subscription(db: Session, user_id: int) -> Subscription:
        """Get active subscription for user."""
        return db.query(Subscription).filter(
            Subscription.user_id == user_id,
            Subscription.status == SubscriptionStatus.ACTIVE
        ).first()
    
    @staticmethod
    def get_subscription_by_id(db: Session, subscription_id: int) -> Subscription:
        """Get subscription by ID."""
        return db.query(Subscription).filter(Subscription.id == subscription_id).first()
    
    @staticmethod
    def list_subscriptions(db: Session, skip: int = 0, limit:  int = 20) -> list:
        """List all subscriptions (admin only)."""
        return db. query(Subscription).offset(skip).limit(limit).all()
    
    @staticmethod
    def cancel_subscription(db: Session, user_id: int) -> Subscription:
        """Cancel user subscription."""
        subscription = SubscriptionService.get_user_subscription(db, user_id)
        
        if not subscription:
            raise ValueError("No active subscription found")
        
        subscription.status = SubscriptionStatus.CANCELLED
        subscription.cancelled_at = datetime.utcnow()
        
        db.add(subscription)
        db.commit()
        db.refresh(subscription)
        
        logger.info(f"Subscription cancelled for user {user_id}")
        return subscription
    
    @staticmethod
    def get_plan(db: Session, plan_type: PlanType) -> Plan:
        """Get plan details."""
        return db.query(Plan).filter(Plan.plan_type == plan_type).first()
    
    @staticmethod
    def list_plans(db: Session) -> list:
        """List all available plans."""
        return db.query(Plan).all()
    
    @staticmethod
    def upgrade_subscription(db: Session, user_id: int, new_plan_type: PlanType) -> Subscription:
        """Upgrade user subscription."""
        subscription = SubscriptionService.get_user_subscription(db, user_id)
        
        if not subscription:
            raise ValueError("No active subscription found")
        
        new_plan = db.query(Plan).filter(Plan.plan_type == new_plan_type).first()
        
        if not new_plan:
            raise ValueError("New plan not found")
        
        subscription.plan_id = new_plan.id
        db.add(subscription)
        db.commit()
        db.refresh(subscription)
        
        logger.info(f"Subscription upgraded for user {user_id} to {new_plan_type}")
        return subscription