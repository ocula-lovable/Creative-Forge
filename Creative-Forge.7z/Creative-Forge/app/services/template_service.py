from sqlalchemy.orm import Session
from sqlalchemy import desc
from app.models. template import Template, TemplateCategory
from app.core.logging import get_logger
from datetime import datetime

logger = get_logger(__name__)

class TemplateService: 
    @staticmethod
    def create_template(db: Session, user_id: int, name: str, description: str,
                       category:  str, template_type: str, structure: str, **kwargs) -> Template:
        """Create a new template."""
        template = Template(
            user_id=user_id,
            name=name,
            description=description,
            category=TemplateCategory(category),
            template_type=template_type,
            structure=structure,
            is_public=kwargs.get("is_public", False),
            thumbnail_url=kwargs.get("thumbnail_url"),
            tags=kwargs.get("tags"),
        )
        
        db.add(template)
        db.commit()
        db.refresh(template)
        
        logger.info(f"Template created: {template.id} by user {user_id}")
        return template
    
    @staticmethod
    def get_template_by_id(db: Session, template_id: int) -> Template:
        """Get template by ID."""
        return db. query(Template).filter(Template.id == template_id).first()
    
    @staticmethod
    def list_system_templates(db: Session, category: str = None, skip: int = 0, limit:  int = 20) -> list:
        """List system templates."""
        query = db.query(Template).filter(Template.is_system == True)
        
        if category:
            query = query. filter(Template.category == TemplateCategory(category))
        
        return query.order_by(desc(Template.created_at)).offset(skip).limit(limit).all()
    
    @staticmethod
    def list_public_templates(db: Session, category: str = None, skip: int = 0, limit: int = 20) -> list:
        """List public templates."""
        query = db.query(Template).filter(Template.is_public == True)
        
        if category: 
            query = query.filter(Template.category == TemplateCategory(category))
        
        return query.order_by(desc(Template.usage_count)).offset(skip).limit(limit).all()
    
    @staticmethod
    def list_user_templates(db: Session, user_id: int, skip: int = 0, limit:  int = 20) -> list:
        """List user templates."""
        return db.query(Template).filter(
            Template.user_id == user_id
        ).order_by(desc(Template.created_at)).offset(skip).limit(limit).all()
    
    @staticmethod
    def update_template(db:  Session, template_id: int, user_id: int, update_data: dict) -> Template:
        """Update a template."""
        template = db.query(Template).filter(
            Template.id == template_id,
            Template.user_id == user_id
        ).first()
        
        if not template:
            raise ValueError("Template not found")
        
        for field, value in update_data.items():
            setattr(template, field, value)
        
        template.updated_at = datetime. utcnow()
        db.add(template)
        db.commit()
        db.refresh(template)
        
        return template
    
    @staticmethod
    def delete_template(db: Session, template_id: int, user_id: int) -> bool:
        """Delete a template."""
        template = db.query(Template).filter(
            Template.id == template_id,
            Template.user_id == user_id
        ).first()
        
        if not template: 
            raise ValueError("Template not found")
        
        db.delete(template)
        db.commit()
        
        logger.info(f"Template deleted: {template_id}")
        return True
    
    @staticmethod
    def increment_usage(db: Session, template_id: int) -> None:
        """Increment template usage count."""
        template = db. query(Template).filter(Template.id == template_id).first()
        
        if template:
            template. usage_count += 1
            db.add(template)
            db.commit()