from sqlalchemy import Column, Integer, String, Text, DateTime, ForeignKey, Float, Enum as SQLEnum, Index
from sqlalchemy.orm import relationship
from datetime import datetime
import enum
from app.db.base import Base

class JobStatus(str, enum.Enum):
    QUEUED = "queued"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"

class JobType(str, enum.Enum):
    VIDEO_GENERATION = "video_generation"
    IMAGE_GENERATION = "image_generation"
    AVATAR_VIDEO = "avatar_video"
    TTS = "tts"
    EXPORT = "export"
    PROCESSING = "processing"

class Job(Base):
    __tablename__ = "jobs"
    
    id = Column(Integer, primary_key=True, index=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    
    # Job identifiers
    job_id = Column(String(255), unique=True, nullable=False, index=True)  # External job ID
    job_type = Column(SQLEnum(JobType), nullable=False, index=True)
    status = Column(SQLEnum(JobStatus), default=JobStatus.QUEUED, index=True)
    
    # Related resources
    video_id = Column(Integer, ForeignKey("videos.id"), nullable=True)
    image_id = Column(Integer, ForeignKey("images.id"), nullable=True)
    avatar_id = Column(Integer, ForeignKey("avatars.id"), nullable=True)
    
    # Progress
    progress_percentage = Column(Integer, default=0)
    current_step = Column(String(255), nullable=True)
    
    # Error handling
    error_message = Column(Text, nullable=True)
    retry_count = Column(Integer, default=0)
    max_retries = Column(Integer, default=3)
    
    # Metadata
    metadata = Column(String(2048), nullable=True)  # JSON string
    
    # Timing
    created_at = Column(DateTime, default=datetime.utcnow, index=True)
    started_at = Column(DateTime, nullable=True)
    completed_at = Column(DateTime, nullable=True)
    
    # Relationships
    project = relationship("Project", back_populates="jobs")
    user = relationship("User")
    video = relationship("Video", back_populates="job")
    image = relationship("Image", back_populates="job")
    avatar = relationship("Avatar", back_populates="job")
    
    # Indexes
    __table_args__ = (
        Index('idx_jobs_user_project', 'user_id', 'project_id'),
        Index('idx_jobs_status_type', 'status', 'job_type'),
    )