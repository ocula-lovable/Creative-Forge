from sqlalchemy import Column, Integer, String, Text, DateTime, ForeignKey, Boolean, Enum as SQLEnum, Index
from sqlalchemy.orm import relationship
from datetime import datetime
import enum
from app.db.base import Base

class TemplateCategory(str, enum.Enum):
    FITNESS = "fitness"
    BEAUTY = "beauty"
    SAAS = "saas"
    EDUCATION = "education"
    ECOMMERCE = "ecommerce"
    REAL_ESTATE = "real_estate"
    FOOD = "food"
    FASHION = "fashion"
    TECH = "tech"
    OTHER = "other"

class Template(Base):
    __tablename__ = "templates"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)  # NULL for system templates
    
    name = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    thumbnail_url = Column(String(512), nullable=True)
    
    category = Column(SQLEnum(TemplateCategory), nullable=False, index=True)
    template_type = Column(String(50), nullable=False)  # video, image, avatar, ad
    
    # Template structure
    structure = Column(Text, nullable=False)  # JSON string
    
    # Configuration
    is_public = Column(Boolean, default=False, index=True)
    is_system = Column(Boolean, default=False, index=True)
    
    # Metadata
    tags = Column(String(512), nullable=True)
    usage_count = Column(Integer, default=0)
    rating = Column(Float, default=0.0)
    
    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow, index=True)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    user = relationship("User")
    
    # Indexes
    __table_args__ = (
        Index('idx_templates_category_type', 'category', 'template_type'),
    )