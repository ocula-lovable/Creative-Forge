from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Float, Enum as SQLEnum, Index
from sqlalchemy.orm import relationship
from datetime import datetime
import enum
from app.db.base import Base

class AssetType(str, enum.Enum):
    VIDEO = "video"
    IMAGE = "image"
    AUDIO = "audio"
    SCRIPT = "script"
    TEMPLATE = "template"

class Asset(Base):
    __tablename__ = "assets"
    
    id = Column(Integer, primary_key=True, index=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    
    name = Column(String(255), nullable=False)
    description = Column(String(512), nullable=True)
    
    asset_type = Column(SQLEnum(AssetType), nullable=False, index=True)
    file_url = Column(String(512), nullable=False)
    
    # File info
    file_size_mb = Column(Float, nullable=True)
    duration_seconds = Column(Float, nullable=True)
    format = Column(String(20), nullable=True)
    resolution = Column(String(20), nullable=True)
    
    # Metadata
    tags = Column(String(512), nullable=True)  # comma-separated
    metadata = Column(String(2048), nullable=True)  # JSON string
    
    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow, index=True)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    project = relationship("Project", back_populates="assets")
    user = relationship("User")
    
    # Indexes
    __table_args__ = (
        Index('idx_assets_user_project', 'user_id', 'project_id'),
    )