from sqlalchemy import Column, Integer, String, Text, DateTime, ForeignKey, Boolean, Enum as SQLEnum, Index
from sqlalchemy.orm import relationship
from datetime import datetime
import enum
from app.db.base import Base

class NotificationType(str, enum.Enum):
    GENERATION_COMPLETE = "generation_complete"
    GENERATION_FAILED = "generation_failed"
    CREDITS_LOW = "credits_low"
    SUBSCRIPTION_EXPIRING = "subscription_expiring"
    SYSTEM_UPDATE = "system_update"
    SUPPORT_RESPONSE = "support_response"

class Notification(Base):
    __tablename__ = "notifications"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    
    notification_type = Column(SQLEnum(NotificationType), nullable=False, index=True)
    title = Column(String(255), nullable=False)
    message = Column(Text, nullable=False)
    
    # Metadata
    data = Column(String(1024), nullable=True)  # JSON string
    action_url = Column(String(512), nullable=True)
    
    # Status
    is_read = Column(Boolean, default=False, index=True)
    read_at = Column(DateTime, nullable=True)
    
    created_at = Column(DateTime, default=datetime.utcnow, index=True)
    
    # Relationships
    user = relationship("User", back_populates="notifications")
    
    # Indexes
    __table_args__ = (
        Index('idx_notifications_user', 'user_id'),
        Index('idx_notifications_type', 'notification_type'),
    )