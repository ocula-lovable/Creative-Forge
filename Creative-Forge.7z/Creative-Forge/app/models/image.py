from sqlalchemy import Column, Integer, String, Text, DateTime, ForeignKey, Float, Enum as SQLEnum, Index
from sqlalchemy.orm import relationship
from datetime import datetime
import enum
from app.db.base import Base

class ImageStatus(str, enum.Enum):
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"

class ImageType(str, enum.Enum):
    AD = "ad"
    POSTER = "poster"
    THUMBNAIL = "thumbnail"
    CHARACTER = "character"
    PRODUCT = "product"
    CUSTOM = "custom"

class Image(Base):
    __tablename__ = "images"
    
    id = Column(Integer, primary_key=True, index=True)
    project_id = Column(Integer, ForeignKey("projects. id"), nullable=False, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    
    title = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    
    # Image details
    image_type = Column(SQLEnum(ImageType), default=ImageType.CUSTOM)
    status = Column(SQLEnum(ImageStatus), default=ImageStatus.PENDING, index=True)
    
    prompt = Column(Text, nullable=False)
    style = Column(String(100), nullable=True)  # realistic, 3d, anime, illustration
    
    # File information
    image_url = Column(String(512), nullable=True)
    
    # Technical details
    resolution = Column(String(20), default="1024x1024")
    format = Column(String(10), default="png")
    file_size_mb = Column(Float, nullable=True)
    
    # Generation details
    model_used = Column(String(100), nullable=True)
    generation_params = Column(String(2048), nullable=True)
    error_message = Column(Text, nullable=True)
    
    # Credits
    credits_used = Column(Float, default=0.0)
    
    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow, index=True)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    completed_at = Column(DateTime, nullable=True)
    
    # Relationships
    project = relationship("Project", back_populates="images")
    user = relationship("User")
    job = relationship("Job", back_populates="image", uselist=False)
    
    # Indexes
    __table_args__ = (
        Index('idx_images_user_project', 'user_id', 'project_id'),
        Index('idx_images_status', 'status'),
    )