from sqlalchemy import Column, Integer, String, Text, DateTime, ForeignKey, Float, Enum as SQLEnum, Index
from sqlalchemy.orm import relationship
from datetime import datetime
import enum
from app.db.base import Base

class VideoStatus(str, enum.Enum):
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"

class VideoType(str, enum.Enum):
    UGC = "ugc"
    AD = "ad"
    EXPLAINER = "explainer"
    PRODUCT = "product"
    SHORTS = "shorts"
    CUSTOM = "custom"

class Video(Base):
    __tablename__ = "videos"
    
    id = Column(Integer, primary_key=True, index=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    
    title = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    
    # Video details
    video_type = Column(SQLEnum(VideoType), default=VideoType. CUSTOM)
    status = Column(SQLEnum(VideoStatus), default=VideoStatus.PENDING, index=True)
    
    prompt = Column(Text, nullable=False)
    script = Column(Text, nullable=True)
    
    # File information
    video_url = Column(String(512), nullable=True)
    thumbnail_url = Column(String(512), nullable=True)
    
    # Technical details
    duration_seconds = Column(Float, nullable=True)
    resolution = Column(String(20), default="1080p")  # 720p, 1080p, 4k
    format = Column(String(10), default="mp4")
    file_size_mb = Column(Float, nullable=True)
    
    # Generation details
    model_used = Column(String(100), nullable=True)  # e.g., "Replicate Stable Video"
    generation_params = Column(String(2048), nullable=True)  # JSON string
    error_message = Column(Text, nullable=True)
    
    # Credits
    credits_used = Column(Float, default=0.0)
    
    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow, index=True)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime. utcnow)
    completed_at = Column(DateTime, nullable=True)
    
    # Relationships
    project = relationship("Project", back_populates="videos")
    user = relationship("User")
    job = relationship("Job", back_populates="video", uselist=False)
    
    # Indexes
    __table_args__ = (
        Index('idx_videos_user_project', 'user_id', 'project_id'),
        Index('idx_videos_status', 'status'),
    )