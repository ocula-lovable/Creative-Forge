from typing import Any, Optional, Generic, TypeVar

T = TypeVar('T')

class StandardResponse(Generic[T]):
    """Standard API response wrapper."""
    
    def __init__(self, 
                 success: bool = True,
                 data: Optional[T] = None,
                 message: str = "",
                 error:  Optional[str] = None):
        self.success = success
        self.data = data
        self.message = message
        self.error = error
    
    def dict(self) -> dict:
        return {
            "success": self. success,
            "data": self.data,
            "message":  self.message,
            "error": self.error
        }

class ErrorResponse: 
    """Error response."""
    
    def __init__(self, message: str, code: str = "ERROR", details: Optional[dict] = None):
        self.message = message
        self.code = code
        self.details = details or {}
    
    def dict(self) -> dict:
        return {
            "success": False,
            "error": {
                "message": self.message,
                "code": self. code,
                "details": self.details
            }
        }

class SuccessResponse: 
    """Success response."""
    
    def __init__(self, data: Any = None, message: str = "Success"):
        self.data = data
        self.message = message
    
    def dict(self) -> dict:
        return {
            "success": True,
            "data": self.data,
            "message": self.message
        }