import re
from typing import Optional

def validate_email(email: str) -> bool:
    """Validate email format."""
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pattern, email) is not None

def validate_username(username: str) -> bool:
    """Validate username format."""
    pattern = r'^[a-zA-Z0-9_-]{3,255}$'
    return re. match(pattern, username) is not None

def validate_password(password: str) -> tuple[bool, str]:
    """Validate password strength."""
    if len(password) < 6:
        return False, "Password must be at least 6 characters"
    
    if not re. search(r'[a-z]', password):
        return False, "Password must contain lowercase letter"
    
    if not re.search(r'[A-Z]', password):
        return False, "Password must contain uppercase letter"
    
    if not re.search(r'[0-9]', password):
        return False, "Password must contain number"
    
    return True, "Password is valid"

def validate_credit_amount(amount: float) -> bool:
    """Validate credit amount."""
    return amount > 0 and amount <= 1000000

def validate_file_extension(filename: str, allowed_extensions: list) -> bool:
    """Validate file extension."""
    ext = filename.split('.')[-1].lower()
    return ext in allowed_extensions

def sanitize_filename(filename: str) -> str:
    """Sanitize filename."""
    # Remove special characters
    filename = re.sub(r'[^a-zA-Z0-9._-]', '_', filename)
    # Remove multiple underscores
    filename = re.sub(r'_+', '_', filename)
    # Limit length
    return filename[:255]