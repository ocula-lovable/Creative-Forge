from pydantic import BaseModel
from typing import Generic, TypeVar, List

T = TypeVar('T')

class PaginationParams(BaseModel):
    skip: int = 0
    limit: int = 20
    
    class Config: 
        json_schema_extra = {
            "example": {
                "skip": 0,
                "limit": 20
            }
        }

class PaginatedResponse(BaseModel, Generic[T]):
    items: List[T]
    total: int
    skip: int
    limit: int
    
    @property
    def has_next(self) -> bool:
        return (self.skip + self.limit) < self.total
    
    @property
    def has_previous(self) -> bool:
        return self.skip > 0