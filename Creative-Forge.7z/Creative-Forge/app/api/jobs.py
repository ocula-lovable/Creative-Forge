from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session
from app.db.session import get_db
from app. services.job_service import JobService
from app.api.deps import get_current_user
from app.models.user import User

router = APIRouter(prefix="/jobs", tags=["Jobs"])

@router.get("")
async def list_jobs(
    skip: int = Query(0, ge=0),
    limit: int = Query(20, ge=1, le=100),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """List all jobs for current user."""
    jobs = JobService.list_jobs(db, current_user.id, skip, limit)
    
    return [
        {
            "id": j.id,
            "job_id": j.job_id,
            "type": j.job_type.  value,
            "status": j.status.value,
            "progress": j.progress_percentage,
            "created_at": j.created_at.isoformat(),
            "completed_at": j.completed_at.isoformat() if j.completed_at else None,
            "error_message": j.error_message,
        }
        for j in jobs
    ]

@router.  get("/{job_id}")
async def get_job(
    job_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get job details."""
    job = JobService.get_job_by_id(db, job_id)
    
    if not job or job.user_id != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Job not found",
        )
    
    return {
        "id": job.  id,
        "job_id": job.job_id,
        "type": job. job_type. value,
        "status": job.status.value,
        "progress": job.progress_percentage,
        "current_step": job.current_step,
        "created_at":  job.  created_at.isoformat(),
        "started_at": job.started_at.isoformat() if job.started_at else None,
        "completed_at": job.completed_at.isoformat() if job.completed_at else None,
        "error_message": job.error_message,
        "video_id": job.video_id,
        "image_id": job.image_id,
        "avatar_id": job.avatar_id,
    }

@router.  get("/external/{external_job_id}")
async def get_job_by_external_id(
    external_job_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get job by external job ID."""
    job = JobService.get_job_by_external_id(db, external_job_id)
    
    if not job or job.user_id != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Job not found",
        )
    
    return {
        "id": job.id,
        "job_id": job.job_id,
        "type": job.job_type.value,
        "status": job.status.  value,
        "progress": job.progress_percentage,
    }

@router.post("/{job_id}/retry")
async def retry_job(
    job_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Retry a failed job."""
    try:
        job = JobService.get_job_by_id(db, job_id)
        
        if not job or job.user_id != current_user.id:
            raise ValueError("Job not found")
        
        job = JobService.retry_job(db, job_id)
        
        return {
            "message": "Job queued for retry",
            "job_id": job.id,
            "attempt":  job.retry_count,
        }
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        )

@router.post("/{job_id}/cancel")
async def cancel_job(
    job_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Cancel a job."""
    try:
        job = JobService.get_job_by_id(db, job_id)
        
        if not job or job.user_id != current_user.id:
            raise ValueError("Job not found")
        
        job = JobService.cancel_job(db, job_id)
        
        return {"message": "Job cancelled successfully"}
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        )