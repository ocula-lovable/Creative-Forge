from fastapi import APIRouter, Depends, HTTPException, status, BackgroundTasks
from sqlalchemy. orm import Session
from app.db.session import get_db
from app.services.project_service import ProjectService
from app.services.job_service import JobService
from app.api.deps import get_current_user
from app.models.user import User
from app.models. job import JobType
from app.tasks.export_tasks import export_project_task
from pydantic import BaseModel

router = APIRouter(prefix="/export", tags=["Export"])

class ExportRequest(BaseModel):
    project_id: int
    format: str = "mp4"  # mp4, gif, images
    quality: str = "high"  # low, medium, high

@router.post("")
async def export_project(
    request: ExportRequest,
    background_tasks: BackgroundTasks,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Export a project."""
    try:
        # Verify project
        project = ProjectService.get_project_by_id(db, request.project_id, current_user. id)
        if not project: 
            raise ValueError("Project not found")
        
        # Create job
        job = JobService.  create_job(
            db,
            current_user.id,
            request.project_id,
            JobType.  EXPORT,
        )
        
        # Queue export task
        background_tasks.add_task(
            export_project_task,
            project_id=request.project_id,
            job_id=job.  id,
            format=request. format,
            quality=request.  quality,
            user_id=current_user.id,
        )
        
        return {
            "message": "Export started",
            "job_id": job.id,
            "project_id": request.project_id,
        }
    
    except ValueError as e:
        raise HTTPException(
            status_code=status.  HTTP_400_BAD_REQUEST,
            detail=str(e),
        )

@router.get("/download/{project_id}")
async def download_export(
    project_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Download exported project."""
    try:
        # Verify project
        project = ProjectService.get_project_by_id(db, project_id, current_user.id)
        if not project:
            raise ValueError("Project not found")
        
        # Get download URL
        from app.integrations.supabase_client import SupabaseClient
        supabase = SupabaseClient()
        
        # Construct file path
        export_path = f"exports/{current_user.id}/{project_id}/export. mp4"
        download_url = supabase.get_file_url("content", export_path)
        
        return {
            "download_url": download_url,
            "project_id": project_id,
        }
    
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e),
        )