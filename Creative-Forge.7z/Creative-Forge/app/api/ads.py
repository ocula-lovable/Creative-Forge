from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.services.project_service import ProjectService
from app.api.deps import get_current_user
from app.models.user import User
from app.integrations.openai_client import OpenAIClient
from pydantic import BaseModel
from typing import Optional

router = APIRouter(prefix="/ads", tags=["Ads"])

class AdRequest(BaseModel):
    project_id: int
    product_name: str
    target_audience: str
    platform: str  # facebook, tiktok, youtube, instagram
    style: Optional[str] = "casual"

class AdResponse(BaseModel):
    hooks: list[str]
    ctas: list[str]
    scripts: list[str]
    duration_seconds: int

@router.post("/generate", response_model=AdResponse)
async def generate_ad(
    request: AdRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Generate ad copy and hooks for a product."""
    try:
        # Verify project
        project = ProjectService.get_project_by_id(db, request.project_id, current_user.id)
        if not project:
            raise ValueError("Project not found")
        
        # Generate using OpenAI
        openai_client = OpenAIClient()
        
        # Generate hooks
        hooks = openai_client.generate_ad_hooks(request.product_name, request.target_audience)
        
        # Generate CTAs
        ctasList = []
        for _ in range(3):
            cta = openai_client.generate_cta(request.product_name, request.platform)
            ctasList.append(cta)
        
        # Generate scripts
        scripts = []
        durations = [15, 30, 60]
        for duration in durations: 
            prompt = f"Write a {duration}-second ad script for {request.product_name} targeting {request.target_audience}"
            script = openai_client.generate_script(prompt, duration // 60, request.style)
            scripts.append(script)
        
        return {
            "hooks": hooks[: 5],
            "ctas": ctasList,
            "scripts": scripts,
            "duration_seconds": 60,
        }
    
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to generate ads",
        )

@router.post("/platform-preset")
async def get_platform_preset(
    platform: str,
    current_user: User = Depends(get_current_user)
):
    """Get platform-specific presets for ads."""
    
    presets = {
        "tiktok": {
            "aspect_ratio": "9:16",
            "max_duration": 60,
            "min_duration": 9,
            "recommended_duration": 21,
            "optimal_hooks": 3,
            "hook_placement": "first_3_seconds",
        },
        "instagram": {
            "aspect_ratio": "9:16",
            "max_duration": 60,
            "min_duration":  3,
            "recommended_duration":  15,
            "optimal_hooks": 2,
            "hook_placement": "first_second",
        },
        "facebook": {
            "aspect_ratio": "16:9",
            "max_duration": 120,
            "min_duration":  6,
            "recommended_duration":  15,
            "optimal_hooks":  2,
            "hook_placement": "first_3_seconds",
        },
        "youtube": {
            "aspect_ratio": "16:9",
            "max_duration": 300,
            "min_duration":  6,
            "recommended_duration":  30,
            "optimal_hooks":  1,
            "hook_placement":  "first_5_seconds",
        },
    }
    
    preset = presets.get(platform. lower())
    
    if not preset:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Unknown platform",
        )
    
    return preset