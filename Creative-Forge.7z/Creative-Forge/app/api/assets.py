from fastapi import APIRouter, Depends, HTTPException, status, Query, UploadFile, File
from sqlalchemy.orm import Session
from app.db.session import get_db
from app. services.asset_service import AssetService
from app.services.project_service import ProjectService
from app.integrations.supabase_client import SupabaseClient
from app.api.deps import get_current_user
from app.models.user import User
import uuid
from app.core.config import settings

router = APIRouter(prefix="/assets", tags=["Assets"])

@router.post("/upload")
async def upload_asset(
    project_id: int,
    file: UploadFile = File(...  ),
    asset_type: str = "video",
    current_user:   User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Upload an asset file."""
    try:
        # Verify project
        project = ProjectService.get_project_by_id(db, project_id, current_user.  id)
        if not project:  
            raise ValueError("Project not found")
        
        # Check file size
        contents = await file.read()
        file_size_mb = len(contents) / (1024 * 1024)
        
        if file_size_mb > settings.MAX_FILE_SIZE_MB:
            raise ValueError(f"File too large. Max:   {settings.MAX_FILE_SIZE_MB}MB")
        
        # Check extension
        file_ext = file.filename.split(".")[-1].lower()
        if file_ext not in settings.ALLOWED_EXTENSIONS:  
            raise ValueError(f"File type not allowed. Allowed: {settings.ALLOWED_EXTENSIONS}")
        
        # Upload to Supabase
        supabase_client = SupabaseClient()
        file_path = f"assets/{current_user.id}/{project_id}/{uuid.uuid4().hex}.{file_ext}"
        
        result = supabase_client.upload_file("content", file_path, contents)
        
        if result["status"] != "success":
            raise ValueError("Upload failed")
        
        # Create asset record
        asset = AssetService.create_asset(
            db,
            current_user.id,
            project_id,
            file.  filename,
            asset_type,
            result["url"],
            file_size_mb=file_size_mb,
            format=file_ext,
        )
        
        return {
            "id": asset.id,
            "name": asset.name,
            "url": asset.file_url,
            "file_size_mb": file_size_mb,
        }
    
    except ValueError as e:
        raise HTTPException(
            status_code=status.  HTTP_400_BAD_REQUEST,
            detail=str(e),
        )
    except Exception as e:
        raise HTTPException(
            status_code=status. HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Upload failed",
        )

@router.get("")
async def list_assets(
    project_id: int = Query(None),
    asset_type: str = Query(None),
    skip: int = Query(0, ge=0),
    limit: int = Query(20, ge=1, le=100),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """List all assets for user."""
    assets = AssetService.list_assets(db, current_user.id, project_id, asset_type, skip, limit)
    
    return [
        {
            "id":   a.id,
            "name":   a.name,
            "type": a.asset_type.  value,
            "url": a. file_url,
            "created_at": a.created_at,
        }
        for a in assets
    ]

@router.get("/{asset_id}")
async def get_asset(
    asset_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get asset details."""
    asset = AssetService.  get_asset_by_id(db, asset_id, current_user.id)
    
    if not asset: 
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Asset not found",
        )
    
    return {
        "id":  asset.id,
        "name": asset.  name,
        "type": asset.asset_type. value,
        "url": asset.file_url,
        "size_mb": asset.file_size_mb,
        "created_at": asset.created_at,
    }

@router.delete("/{asset_id}")
async def delete_asset(
    asset_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Delete asset."""
    try:
        asset = AssetService. get_asset_by_id(db, asset_id, current_user.id)
        if not asset:
            raise ValueError("Asset not found")
        
        # Delete from Supabase
        supabase_client = SupabaseClient()
        file_key = asset.file_url.split("/content/")[1]
        supabase_client.delete_file("content", file_key)
        
        # Delete record
        AssetService.delete_asset(db, asset_id, current_user.id)
        
        return {"message": "Asset deleted successfully"}
    
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e),
        )