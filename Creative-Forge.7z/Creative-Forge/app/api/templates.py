from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.services. template_service import TemplateService
from app.api.deps import get_current_user
from app.models.user import User
from pydantic import BaseModel

router = APIRouter(prefix="/templates", tags=["Templates"])

class TemplateCreate(BaseModel):
    name: str
    description: str
    category: str
    template_type: str
    structure: str

class TemplateResponse(BaseModel):
    id: int
    name: str
    description: str
    category: str
    template_type: str
    thumbnail_url: str
    usage_count: int
    rating: float

@router.get("/system", response_model=list[TemplateResponse])
async def list_system_templates(
    category: str = Query(None),
    skip: int = Query(0, ge=0),
    limit: int = Query(20, ge=1, le=100),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """List system templates."""
    templates = TemplateService.list_system_templates(db, category, skip, limit)
    
    return [
        {
            "id": t.id,
            "name": t.  name,
            "description": t.description,
            "category":   t.category. value,
            "template_type": t. template_type,
            "thumbnail_url": t.thumbnail_url,
            "usage_count":  t.usage_count,
            "rating": t.rating,
        }
        for t in templates
    ]

@router.get("/public", response_model=list[TemplateResponse])
async def list_public_templates(
    category: str = Query(None),
    skip: int = Query(0, ge=0),
    limit: int = Query(20, ge=1, le=100),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """List public templates."""
    templates = TemplateService.list_public_templates(db, category, skip, limit)
    
    return [
        {
            "id": t.id,
            "name": t. name,
            "description": t.description,
            "category":  t.  category. value,
            "template_type": t.template_type,
            "thumbnail_url": t. thumbnail_url,
            "usage_count": t.usage_count,
            "rating": t. rating,
        }
        for t in templates
    ]

@router.get("/user", response_model=list[TemplateResponse])
async def list_user_templates(
    skip: int = Query(0, ge=0),
    limit: int = Query(20, ge=1, le=100),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """List user's templates."""
    templates = TemplateService.list_user_templates(db, current_user. id, skip, limit)
    
    return [
        {
            "id": t.id,
            "name": t.name,
            "description": t. description,
            "category": t.  category.value,
            "template_type": t.template_type,
            "thumbnail_url":  t.thumbnail_url,
            "usage_count": t.usage_count,
            "rating":   t.rating,
        }
        for t in templates
    ]

@router.post("", response_model=TemplateResponse)
async def create_template(
    request:  TemplateCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Create a new template."""
    try:
        template = TemplateService. create_template(
            db,
            current_user.id,
            request.name,
            request.description,
            request.category,
            request.template_type,
            request.structure,
        )
        
        return {
            "id": template.id,
            "name": template.name,
            "description": template.description,
            "category": template.category.  value,
            "template_type": template.template_type,
            "thumbnail_url": template.  thumbnail_url,
            "usage_count": template.usage_count,
            "rating": template.  rating,
        }
    
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to create template",
        )

@router.get("/{template_id}")
async def get_template(
    template_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get template details."""
    template = TemplateService.get_template_by_id(db, template_id)
    
    if not template:  
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Template not found",
        )
    
    return {
        "id": template. id,
        "name": template.  name,
        "description": template.description,
        "category":   template.category. value,
        "template_type": template.template_type,
        "structure": template.structure,
        "thumbnail_url": template.thumbnail_url,
        "usage_count": template.usage_count,
        "rating": template.rating,
    }

@router.delete("/{template_id}")
async def delete_template(
    template_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Delete template."""
    try:
        TemplateService.delete_template(db, template_id, current_user.id)
        return {"message": "Template deleted successfully"}
    
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e),
        )