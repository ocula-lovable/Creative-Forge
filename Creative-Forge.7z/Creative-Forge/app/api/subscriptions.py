from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.services. subscription_service import SubscriptionService
from app.integrations.stripe_client import StripeClient
from app.api.deps import get_current_user
from app. models.user import User
from app.models.subscription import PlanType
from pydantic import BaseModel
from datetime import datetime

router = APIRouter(prefix="/subscriptions", tags=["Subscriptions"])

class SubscribeRequest(BaseModel):
    plan_type: str
    billing_cycle:  str = "monthly"

class SubscriptionResponse(BaseModel):
    id: int
    plan_name: str
    status: str
    current_period_start: str
    current_period_end:   str
    price:   float

@router.get("/plans")
async def list_plans(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """List all available plans."""
    plans = SubscriptionService.list_plans(db)
    
    return [
        {
            "id": p.  id,
            "name": p. name,
            "type":   p.plan_type. value,
            "description": p.description,
            "price_monthly": p.price_monthly,
            "price_yearly": p.price_yearly,
            "monthly_credits": p.monthly_credits,
            "features": {
                "has_api_access": p.has_api_access,
                "has_custom_templates": p.has_custom_templates,
                "has_priority_support": p.has_priority_support,
                "has_watermark": p.has_watermark,
                "max_video_duration": p.max_video_duration_minutes,
                "max_concurrent_jobs": p.max_concurrent_jobs,
            }
        }
        for p in plans
    ]

@router.  get("/my-subscription", response_model=SubscriptionResponse)
async def get_my_subscription(
    current_user:   User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get current user's subscription."""
    subscription = SubscriptionService.get_user_subscription(db, current_user.id)
    
    if not subscription:
        # Return free plan
        return {
            "id":   0,
            "plan_name":   "Free",
            "status":  "active",
            "current_period_start":  datetime.utcnow().isoformat(),
            "current_period_end": (datetime.utcnow() + __import__("datetime").timedelta(days=30)).isoformat(),
            "price":   0.0,
        }
    
    return {
        "id":  subscription.id,
        "plan_name": subscription.  plan.  name,
        "status": subscription.status.  value,
        "current_period_start": subscription.current_period_start.  isoformat(),
        "current_period_end": subscription.current_period_end. isoformat(),
        "price": subscription.  plan. price_monthly if subscription.billing_cycle == "monthly" else subscription. plan.price_yearly,
    }

@router.post("/subscribe")
async def subscribe(
    request: SubscribeRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Subscribe to a plan."""
    try:
        plan_type = PlanType(request.  plan_type)
        subscription = SubscriptionService.create_subscription(
            db,
            current_user.id,
            plan_type,
            request.  billing_cycle
        )
        
        # Create Stripe customer and subscription
        stripe_result = StripeClient.create_customer(current_user.email, current_user.full_name)
        
        if stripe_result["status"] == "success":
            subscription.stripe_customer_id = stripe_result["customer_id"]
            db.add(subscription)
            db.commit()
        
        return {
            "message": "Subscription created successfully",
            "subscription_id": subscription.  id,
            "status": subscription.status. value,
        }
    
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        )

@router.post("/cancel")
async def cancel_subscription(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Cancel subscription."""
    try:
        subscription = SubscriptionService.cancel_subscription(db, current_user.  id)
        
        # Cancel Stripe subscription if exists
        if subscription.  stripe_subscription_id:
            StripeClient.cancel_subscription(subscription.  stripe_subscription_id)
        
        return {
            "message": "Subscription cancelled successfully",
            "cancelled_at": subscription. cancelled_at.isoformat(),
        }
    
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e),
        )