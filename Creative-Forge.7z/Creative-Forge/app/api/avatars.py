from fastapi import APIRouter, Depends, HTTPException, status, Query, BackgroundTasks
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.schemas.avatar import AvatarCreate, AvatarUpdate, AvatarResponse, AvatarVideoRequest
from app.services.avatar_service import AvatarService
from app.services.project_service import ProjectService
from app.services. job_service import JobService
from app.api.deps import get_current_user
from app.models. user import User
from app.models.job import JobType
from app.tasks.avatar_tasks import generate_avatar_video_task

router = APIRouter(prefix="/avatars", tags=["Avatars"])

@router.post("", response_model=AvatarResponse)
async def create_avatar(
    avatar_data: AvatarCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Create a new avatar."""
    try:
        # Verify project exists
        project = ProjectService.get_project_by_id(db, avatar_data.project_id, current_user.id)
        if not project:
            raise ValueError("Project not found")
        
        # Create avatar
        avatar = AvatarService.create_avatar(db, current_user. id, avatar_data)
        
        return avatar
    except ValueError as e: 
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        )

@router.get("", response_model=list[AvatarResponse])
async def list_avatars(
    project_id: int = Query(None),
    skip: int = Query(0, ge=0),
    limit: int = Query(20, ge=1, le=100),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """List all avatars for current user."""
    avatars = AvatarService.list_avatars(db, current_user. id, project_id, skip, limit)
    return avatars

@router.get("/{avatar_id}", response_model=AvatarResponse)
async def get_avatar(
    avatar_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get avatar details."""
    avatar = AvatarService.get_avatar_by_id(db, avatar_id, current_user.id)
    
    if not avatar:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Avatar not found",
        )
    
    return avatar

@router.put("/{avatar_id}", response_model=AvatarResponse)
async def update_avatar(
    avatar_id: int,
    update_data: AvatarUpdate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Update avatar."""
    try:
        avatar = AvatarService.update_avatar(db, avatar_id, current_user. id, update_data)
        return avatar
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e),
        )

@router.delete("/{avatar_id}")
async def delete_avatar(
    avatar_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Delete avatar."""
    try:
        AvatarService.delete_avatar(db, avatar_id, current_user.id)
        return {"message": "Avatar deleted successfully"}
    except ValueError as e: 
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e),
        )

@router.post("/{avatar_id}/generate-video")
async def generate_avatar_video(
    avatar_id: int,
    request: AvatarVideoRequest,
    background_tasks: BackgroundTasks,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Generate a talking head video from avatar."""
    try:
        avatar = AvatarService.get_avatar_by_id(db, avatar_id, current_user. id)
        if not avatar:
            raise ValueError("Avatar not found")
        
        # Generate video
        video_config = AvatarService.generate_avatar_video(db, current_user.id, avatar_id, request. script, request.voice_id)
        
        # Create job
        job = JobService.create_job(
            db,
            current_user.id,
            avatar.project_id,
            JobType. AVATAR_VIDEO,
            avatar_id=avatar_id
        )
        
        # Queue background task
        background_tasks. add_task(
            generate_avatar_video_task,
            avatar_id=avatar_id,
            script=request.script,
            voice_id=request.voice_id or avatar.voice_id,
            user_id=current_user.id,
            job_id=job.id
        )
        
        return {
            "message":  "Video generation started",
            "job_id": job.id,
            "avatar_id": avatar_id,
        }
    except ValueError as e: 
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        )

@router.get("/voices/list")
async def get_voices(
    current_user: User = Depends(get_current_user)
):
    """Get available voices for avatars."""
    from app.integrations.elevenlabs_client import ElevenLabsClient
    
    try:
        client = ElevenLabsClient()
        voices = client.get_voices()
        return {
            "voices": voices,
            "total": len(voices),
        }
    except Exception as e: 
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to fetch voices",
        )