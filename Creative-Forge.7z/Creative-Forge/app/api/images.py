from fastapi import APIRouter, Depends, HTTPException, status, Query, BackgroundTasks
from sqlalchemy.orm import Session
from app. db.session import get_db
from app.schemas.image import ImageCreate, ImageUpdate, ImageResponse
from app.services.image_service import ImageService
from app.services.project_service import ProjectService
from app.services.job_service import JobService
from app.api.deps import get_current_user
from app.models.user import User
from app.models.job import JobType
from app.tasks.image_tasks import generate_image_task

router = APIRouter(prefix="/images", tags=["Images"])

@router.post("", response_model=ImageResponse)
async def create_image(
    image_data: ImageCreate,
    background_tasks: BackgroundTasks,
    current_user:  User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Create a new image generation request."""
    try:
        # Verify project exists
        project = ProjectService.get_project_by_id(db, image_data.project_id, current_user.id)
        if not project:
            raise ValueError("Project not found")
        
        # Create image
        image = ImageService.create_image(db, current_user.id, image_data)
        
        # Create job
        job = JobService.create_job(
            db,
            current_user.id,
            image_data.project_id,
            JobType. IMAGE_GENERATION,
            image_id=image.id
        )
        
        # Queue background task
        background_tasks.add_task(
            generate_image_task,
            image_id=image.id,
            prompt=image.prompt,
            style=image.style,
            user_id=current_user.id,
            job_id=job.id
        )
        
        return image
    except ValueError as e:
        raise HTTPException(
            status_code=status. HTTP_400_BAD_REQUEST,
            detail=str(e),
        )

@router.get("", response_model=list[ImageResponse])
async def list_images(
    project_id: int = Query(None),
    image_type: str = Query(None),
    skip: int = Query(0, ge=0),
    limit: int = Query(20, ge=1, le=100),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """List all images for current user."""
    images = ImageService.list_images(db, current_user. id, project_id, skip, limit)
    
    if image_type:
        images = [i for i in images if i.image_type == image_type]
    
    return images

@router.get("/{image_id}", response_model=ImageResponse)
async def get_image(
    image_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get image details."""
    image = ImageService.get_image_by_id(db, image_id, current_user.id)
    
    if not image: 
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Image not found",
        )
    
    return image

@router.put("/{image_id}", response_model=ImageResponse)
async def update_image(
    image_id: int,
    update_data: ImageUpdate,
    current_user:  User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Update image metadata."""
    try:
        image = ImageService.update_image(db, image_id, current_user.id, update_data)
        return image
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e),
        )

@router.delete("/{image_id}")
async def delete_image(
    image_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Delete image."""
    try:
        ImageService.delete_image(db, image_id, current_user.id)
        return {"message": "Image deleted successfully"}
    except ValueError as e: 
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e),
        )