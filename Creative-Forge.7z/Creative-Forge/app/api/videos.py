from fastapi import APIRouter, Depends, HTTPException, status, Query, BackgroundTasks
from sqlalchemy. orm import Session
from app.db.session import get_db
from app.schemas.video import VideoCreate, VideoUpdate, VideoResponse, VideoDetailResponse
from app.services.video_service import VideoService
from app.services.project_service import ProjectService
from app.services.job_service import JobService
from app.api.deps import get_current_user
from app.models. user import User
from app.models.job import JobType
from app.tasks.video_tasks import generate_video_task

router = APIRouter(prefix="/videos", tags=["Videos"])

@router.post("", response_model=VideoResponse)
async def create_video(
    video_data: VideoCreate,
    background_tasks: BackgroundTasks,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Create a new video generation request."""
    try:
        # Verify project exists
        project = ProjectService.get_project_by_id(db, video_data.project_id, current_user.id)
        if not project:
            raise ValueError("Project not found")
        
        # Create video
        video = VideoService.create_video(db, current_user.id, video_data)
        
        # Create job
        job = JobService. create_job(
            db,
            current_user.id,
            video_data.project_id,
            JobType.VIDEO_GENERATION,
            video_id=video.id
        )
        
        # Queue background task
        background_tasks.add_task(
            generate_video_task,
            video_id=video.id,
            prompt=video. prompt,
            user_id=current_user.id,
            job_id=job.id
        )
        
        return video
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        )

@router.get("", response_model=list[VideoResponse])
async def list_videos(
    project_id: int = Query(None),
    status_filter: str = Query(None),
    skip: int = Query(0, ge=0),
    limit: int = Query(20, ge=1, le=100),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """List all videos for current user."""
    videos = VideoService.list_videos(db, current_user.id, project_id, skip, limit)
    
    if status_filter:
        videos = [v for v in videos if v. status == status_filter]
    
    return videos

@router. get("/{video_id}", response_model=VideoDetailResponse)
async def get_video(
    video_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get video details."""
    video = VideoService.get_video_by_id(db, video_id, current_user.id)
    
    if not video: 
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Video not found",
        )
    
    return video

@router.put("/{video_id}", response_model=VideoResponse)
async def update_video(
    video_id:  int,
    update_data: VideoUpdate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Update video metadata."""
    try:
        video = VideoService.update_video(db, video_id, current_user.id, update_data)
        return video
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e),
        )

@router.delete("/{video_id}")
async def delete_video(
    video_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Delete video."""
    try:
        VideoService.delete_video(db, video_id, current_user.id)
        return {"message": "Video deleted successfully"}
    except ValueError as e: 
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e),
        )

@router.post("/{video_id}/regenerate", response_model=VideoResponse)
async def regenerate_video(
    video_id: int,
    background_tasks: BackgroundTasks,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Regenerate a failed video."""
    video = VideoService.get_video_by_id(db, video_id, current_user.id)
    
    if not video:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Video not found",
        )
    
    from app.models.video import VideoStatus
    
    # Reset status
    video.status = VideoStatus. PENDING
    db.add(video)
    db.commit()
    
    # Create new job
    job = JobService. create_job(
        db,
        current_user.id,
        video. project_id,
        JobType.VIDEO_GENERATION,
        video_id=video. id
    )
    
    # Queue task
    background_tasks.add_task(
        generate_video_task,
        video_id=video.id,
        prompt=video.prompt,
        user_id=current_user.id,
        job_id=job. id
    )
    
    return video