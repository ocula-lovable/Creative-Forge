from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.schemas.auth import (
    LoginRequest, SignupRequest, TokenResponse, RefreshTokenRequest
)
from app.services.auth_service import AuthService
from app. api.deps import get_current_user
from app.models.user import User

router = APIRouter(prefix="/auth", tags=["Authentication"])

@router.post("/signup", response_model=TokenResponse)
async def signup(
    signup_data: SignupRequest,
    db: Session = Depends(get_db)
):
    """Register a new user."""
    try:
        user = AuthService. register_user(db, signup_data)
        tokens = AuthService.create_tokens(user. id)
        return tokens
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="An error occurred during registration",
        )

@router.post("/login", response_model=TokenResponse)
async def login(
    login_data: LoginRequest,
    db: Session = Depends(get_db)
):
    """Authenticate user and return tokens."""
    try:
        user = AuthService.authenticate_user(db, login_data. email, login_data.password)
        tokens = AuthService.create_tokens(user.id)
        return tokens
    except ValueError: 
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid email or password",
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="An error occurred during login",
        )

@router.post("/refresh", response_model=TokenResponse)
async def refresh_token(refresh_request: RefreshTokenRequest):
    """Refresh access token."""
    try:
        new_token = AuthService.refresh_access_token(refresh_request.refresh_token)
        return {
            "access_token": new_token,
            "refresh_token": refresh_request.refresh_token,
            "token_type": "bearer",
            "expires_in": 1800,
        }
    except ValueError: 
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid refresh token",
        )

@router.get("/me")
async def get_current_user_info(
    current_user:  User = Depends(get_current_user)
):
    """Get current user information."""
    return {
        "id": current_user.id,
        "email": current_user.email,
        "username": current_user.username,
        "full_name": current_user.full_name,
        "avatar_url": current_user.avatar_url,
        "available_credits": current_user.available_credits,
        "total_credits_used": current_user.total_credits_used,
        "is_verified": current_user.is_verified,
        "created_at": current_user.created_at,
        "role": current_user.role.value,
    }

@router.post("/logout")
async def logout(current_user: User = Depends(get_current_user)):
    """Logout user (client-side token removal)."""
    return {"message": "Logged out successfully"}