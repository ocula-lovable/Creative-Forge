from fastapi import APIRouter
from app.core.config import settings

router = APIRouter()

@router.get("/health")
async def health_check():
    """Health check endpoint."""
    return {
        "status": "healthy",
        "app":  settings.APP_NAME,
        "version": settings.APP_VERSION,
        "environment":  settings. ENVIRONMENT,
    }

@router.get("/version")
async def version():
    """Get API version."""
    return {
        "version": settings.APP_VERSION,
        "name": settings.APP_NAME,
    }

@router.get("/status")
async def status():
    """Get detailed status."""
    return {
        "status": "operational",
        "app":  settings.APP_NAME,
        "version": settings.APP_VERSION,
        "environment": settings. ENVIRONMENT,
        "debug": settings.DEBUG,
    }