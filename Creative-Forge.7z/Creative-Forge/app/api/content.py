from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.api.deps import get_current_user
from app.models.user import User
from app.integrations.openai_client import OpenAIClient
from pydantic import BaseModel

router = APIRouter(prefix="/content", tags=["Content"])

class ScriptRequest(BaseModel):
    prompt: str
    duration_minutes: int = 1
    style: str = "casual"

class MultiVariantRequest(BaseModel):
    prompt: str
    num_variants: int = 3

@router.post("/script")
async def generate_script(
    request: ScriptRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Generate a video script from a prompt."""
    try:
        openai_client = OpenAIClient()
        script = openai_client.generate_script(
            request.prompt,
            request.duration_minutes,
            request.style
        )
        
        return {
            "script": script,
            "duration_minutes": request.duration_minutes,
            "style": request. style,
        }
    
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to generate script",
        )

@router.post("/variants")
async def generate_variants(
    request: MultiVariantRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Generate multiple variants of content for A/B testing."""
    try:
        openai_client = OpenAIClient()
        variants = []
        
        for i in range(request.num_variants):
            script = openai_client.generate_script(
                request.prompt,
                duration_minutes=1,
                style="casual"
            )
            variants.append({
                "variant":  chr(65 + i),  # A, B, C, etc.
                "content": script,
            })
        
        return {
            "prompt": request.prompt,
            "num_variants": request.num_variants,
            "variants": variants,
        }
    
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to generate variants",
        )

@router.post("/storyboard")
async def generate_storyboard(
    prompt: str,
    current_user: User = Depends(get_current_user)
):
    """Generate storyboard/shot list for a video."""
    try:
        openai_client = OpenAIClient()
        
        system_prompt = "Create a detailed storyboard with scene descriptions, shots, and timing."
        response = openai_client.client.chat.completions.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content":  system_prompt},
                {"role": "user", "content": f"Create storyboard for:  {prompt}"},
            ],
            temperature=0.7,
            max_tokens=2000,
        )
        
        storyboard = response.choices[0].message.content
        
        # Parse storyboard into scenes
        scenes = storyboard.split("\n\n")
        
        return {
            "prompt": prompt,
            "storyboard": storyboard,
            "scenes": scenes,
            "total_scenes": len(scenes),
        }
    
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to generate storyboard",
        )