from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from contextlib import asynccontextmanager

from app.core.config import settings
from app. core.logging import get_logger
from app.db.session import engine
from app.models.base import Base
from app.api import (
    auth, users, projects, videos, images, avatars, ads, content,
    assets, templates, subscriptions, jobs, export, notifications, health
)
from app.middleware.error_handler import ErrorHandlerMiddleware

logger = get_logger(__name__)

# Create tables on startup
def create_tables():
    Base.metadata.create_all(bind=engine)

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    logger.info("Starting up Creative Forge API")
    create_tables()
    yield
    # Shutdown
    logger. info("Shutting down Creative Forge API")

# Initialize FastAPI
app = FastAPI(
    title="Creative Forge API",
    description="API for AI-powered content generation",
    version="1.0.0",
    lifespan=lifespan
)

# Middleware
app.add_middleware(ErrorHandlerMiddleware)
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.add_middleware(
    TrustedHostMiddleware,
    allowed_hosts=settings. ALLOWED_HOSTS
)

# API Routes
api_prefix = "/api/v1"

app.include_router(health.router, prefix=api_prefix, tags=["Health"])
app.include_router(auth.router, prefix=api_prefix, tags=["Authentication"])
app.include_router(users. router, prefix=api_prefix, tags=["Users"])
app.include_router(projects.router, prefix=api_prefix, tags=["Projects"])
app.include_router(videos.router, prefix=api_prefix, tags=["Videos"])
app.include_router(images.router, prefix=api_prefix, tags=["Images"])
app.include_router(avatars.router, prefix=api_prefix, tags=["Avatars"])
app.include_router(ads.router, prefix=api_prefix, tags=["Ads"])
app.include_router(content. router, prefix=api_prefix, tags=["Content"])
app.include_router(assets.router, prefix=api_prefix, tags=["Assets"])
app.include_router(templates.router, prefix=api_prefix, tags=["Templates"])
app.include_router(subscriptions.router, prefix=api_prefix, tags=["Subscriptions"])
app.include_router(jobs.router, prefix=api_prefix, tags=["Jobs"])
app.include_router(export.router, prefix=api_prefix, tags=["Export"])
app.include_router(notifications.router, prefix=api_prefix, tags=["Notifications"])

@app.get("/")
async def root():
    return {
        "message": "Creative Forge API",
        "version": "1.0.0",
        "docs":  "/docs"
    }

if __name__ == "__main__": 
    import uvicorn
    uvicorn.run(
        app,
        host="0.0.0.0",
        port=8000
    )