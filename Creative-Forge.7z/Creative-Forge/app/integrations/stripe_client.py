import stripe
from app.core.config import settings
from app.core.logging import get_logger

logger = get_logger(__name__)

if settings.STRIPE_SECRET_KEY:
    stripe.api_key = settings.STRIPE_SECRET_KEY

class StripeClient: 
    """Client for Stripe - payments and subscriptions."""
    
    @staticmethod
    def create_customer(email: str, name: str = None) -> dict:
        """Create a Stripe customer."""
        if not settings.STRIPE_SECRET_KEY: 
            return {"status": "error", "error": "Stripe not configured"}
        
        try: 
            logger.info(f"Creating Stripe customer: {email}")
            
            customer = stripe.Customer.create(
                email=email,
                name=name,
            )
            
            logger.info(f"Customer created: {customer. id}")
            
            return {
                "status": "success",
                "customer_id": customer.id,
            }
        
        except Exception as e: 
            logger.error(f"Customer creation failed: {str(e)}")
            return {
                "status": "error",
                "error": str(e),
            }
    
    @staticmethod
    def create_subscription(customer_id: str, price_id: str, billing_cycle: str = "month") -> dict:
        """Create a Stripe subscription."""
        if not settings.STRIPE_SECRET_KEY:
            return {"status": "error", "error": "Stripe not configured"}
        
        try:
            logger.info(f"Creating subscription for customer: {customer_id}")
            
            subscription = stripe. Subscription.create(
                customer=customer_id,
                items=[
                    {"price": price_id},
                ],
                payment_behavior="default_incomplete",
                expand=["latest_invoice. payment_intent"],
            )
            
            logger.info(f"Subscription created: {subscription.id}")
            
            return {
                "status": "success",
                "subscription_id": subscription.id,
                "client_secret": subscription.latest_invoice.payment_intent. client_secret,
            }
        
        except Exception as e: 
            logger.error(f"Subscription creation failed: {str(e)}")
            return {
                "status": "error",
                "error": str(e),
            }
    
    @staticmethod
    def cancel_subscription(subscription_id: str) -> dict:
        """Cancel a subscription."""
        if not settings. STRIPE_SECRET_KEY:
            return {"status": "error", "error": "Stripe not configured"}
        
        try:
            logger.info(f"Cancelling subscription: {subscription_id}")
            
            subscription = stripe.Subscription.delete(subscription_id)
            
            logger.info(f"Subscription cancelled: {subscription_id}")
            
            return {
                "status": "success",
            }
        
        except Exception as e:
            logger. error(f"Subscription cancellation failed: {str(e)}")
            return {
                "status": "error",
                "error": str(e),
            }
    
    @staticmethod
    def get_subscription(subscription_id: str) -> dict:
        """Get subscription details."""
        if not settings.STRIPE_SECRET_KEY:
            return {"status": "error", "error": "Stripe not configured"}
        
        try:
            subscription = stripe.Subscription.retrieve(subscription_id)
            
            return {
                "status": "success",
                "subscription": subscription,
            }
        
        except Exception as e:
            logger.error(f"Failed to get subscription: {str(e)}")
            return {
                "status": "error",
                "error": str(e),
            }