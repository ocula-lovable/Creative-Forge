import replicate
from app.core.config import settings
from app.core.logging import get_logger
import json

logger = get_logger(__name__)

class ReplicateClient: 
    """Client for Replicate API - text-to-video generation."""
    
    def __init__(self):
        self.api_token = settings.REPLICATE_API_KEY
        if self.api_token:
            replicate.api_token = self.api_token
    
    def generate_video(self, prompt: str, duration: int = 60, **kwargs) -> dict:
        """Generate video from text prompt."""
        if not self.api_token:
            return {"status": "error", "error": "Replicate API key not configured"}
        
        try: 
            logger.info(f"Generating video with prompt: {prompt[: 100]}")
            
            # Using Stable Video Diffusion or similar
            output = replicate.run(
                "cjwbw/stable-video-diffusion-img2vid-xt: 3f0457e4619daac51203dedb3df21be3470b4538bab9183307fa7d6f0b1aeb39",
                input={
                    "prompt": prompt,
                    "duration": min(duration, 60),  # Max 60 seconds
                    "fps": 24,
                    "output_format": "mp4",
                }
            )
            
            logger.info(f"Video generation completed")
            
            return {
                "status":  "success",
                "output_url": output,
                "model":   "stable-video-diffusion",
            }
        
        except Exception as e:  
            logger.error(f"Video generation failed: {str(e)}")
            return {
                "status": "error",
                "error": str(e),
            }
    
    def check_status(self, prediction_id: str) -> dict:
        """Check status of a prediction."""
        if not self.api_token:
            return {"status": "error", "error": "Replicate API key not configured"}
        
        try:
            prediction = replicate.predictions.get(prediction_id)
            
            return {
                "status": prediction.status,
                "output":   prediction.output,
                "error":  prediction.error,
            }
        except Exception as e:
            logger.error(f"Status check failed: {str(e)}")
            return {
                "status": "error",
                "error": str(e),
            }