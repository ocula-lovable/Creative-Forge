import requests
import base64
from app.core.config import settings
from app.core. logging import get_logger

logger = get_logger(__name__)

class StabilityClient:
    """Client for Stability AI API - image generation."""
    
    BASE_URL = "https://api.stability.ai/v1"
    
    def __init__(self):
        self.api_key = settings.STABILITY_API_KEY
        self.headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Accept": "application/json",
        }
    
    def generate_image(self, prompt: str, style: str = "realistic", 
                      width: int = 1024, height: int = 1024) -> dict:
        """Generate an image from text prompt."""
        if not self. api_key:
            return {"status": "error", "error":  "API key not configured"}
        
        try:
            logger. info(f"Generating image:  {prompt[:100]}")
            
            payload = {
                "text_prompts": [
                    {
                        "text": prompt,
                        "weight": 1
                    }
                ],
                "cfg_scale": 7,
                "sampler": "k_dpmpp_2m",
                "samples": 1,
                "steps": 30,
                "style_preset": style,
                "height": height,
                "width":   width,
            }
            
            response = requests.post(
                f"{self.BASE_URL}/generation/stable-diffusion-v1-6/text-to-image",
                json=payload,
                headers=self.headers,
            )
            response.raise_for_status()
            
            data = response.json()
            logger.info("Image generation successful")
            
            return {
                "status": "success",
                "images": data.get("artifacts", []),
                "model": "stable-diffusion-v1-6",
            }
        
        except Exception as e:
            logger.error(f"Image generation failed: {str(e)}")
            return {
                "status": "error",
                "error": str(e),
            }
    
    def upscale_image(self, image_data: bytes) -> dict:
        """Upscale an existing image."""
        if not self. api_key:
            return {"status": "error", "error":  "API key not configured"}
        
        try:
            logger. info("Upscaling image")
            
            payload = {
                "image": base64.b64encode(image_data).decode(),
                "upscale": 2,
            }
            
            response = requests.post(
                f"{self.BASE_URL}/generation/stable-diffusion-v1-6/image-to-image-upscale",
                json=payload,
                headers=self. headers,
            )
            response.raise_for_status()
            
            data = response.json()
            logger.info("Image upscaling successful")
            
            return {
                "status":  "success",
                "images":  data.get("artifacts", []),
            }
        
        except Exception as e: 
            logger.error(f"Image upscaling failed: {str(e)}")
            return {
                "status": "error",
                "error": str(e),
            }