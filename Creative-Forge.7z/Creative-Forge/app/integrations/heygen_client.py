import requests
import json
from app.core.config import settings
from app.core. logging import get_logger

logger = get_logger(__name__)

class HeyGenClient:
    """Client for HeyGen API - avatar video generation."""
    
    BASE_URL = "https://api.heygen.com/v1"
    
    def __init__(self):
        self.api_key = settings.  HEYGEN_API_KEY
        self.headers = {
            "X-Api-Key": self.api_key,
            "Content-Type":  "application/json",
        }
    
    def get_avatars(self) -> list:
        """Get available avatars."""
        if not self.api_key:
            return []
        
        try: 
            response = requests.get(
                f"{self.BASE_URL}/avatars",
                headers=self.headers
            )
            response.raise_for_status()
            
            avatars = response.json().get("data", [])
            logger.info(f"Retrieved {len(avatars)} avatars")
            
            return avatars
        
        except Exception as e:
            logger.error(f"Failed to get avatars: {str(e)}")
            raise
    
    def create_video(self, avatar_id: str, script: str, voice_id: str = None) -> dict:
        """Create an avatar video."""
        if not self.api_key:
            return {"status": "error", "error": "API key not configured"}
        
        try:
            logger.info(f"Creating avatar video with script: {script[:100]}")
            
            payload = {
                "avatar_id": avatar_id,
                "script": script,
                "voice_id": voice_id or "default",
                "quality": "high",
            }
            
            response = requests.post(
                f"{self.BASE_URL}/video_requests",
                json=payload,
                headers=self.headers
            )
            response.raise_for_status()
            
            data = response.json()
            logger.info(f"Avatar video creation initiated: {data.get('id')}")
            
            return {
                "status": "success",
                "video_id": data.get("id"),
                "video_request_id": data.get("video_request_id"),
            }
        
        except Exception as e:
            logger.error(f"Avatar video creation failed: {str(e)}")
            return {
                "status": "error",
                "error": str(e),
            }
    
    def get_video_status(self, video_id: str) -> dict:
        """Get status of a video generation."""
        if not self.api_key:
            return {"status": "error", "error": "API key not configured"}
        
        try:
            response = requests.get(
                f"{self.BASE_URL}/video_requests/{video_id}",
                headers=self.headers
            )
            response.raise_for_status()
            
            data = response.json()
            
            return {
                "status": data.get("status"),
                "video_url": data.get("video_url"),
                "progress": data.get("progress"),
            }
        
        except Exception as e:
            logger.error(f"Failed to get video status: {str(e)}")
            return {
                "status": "error",
                "error": str(e),
            }