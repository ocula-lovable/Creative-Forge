from openai import OpenAI
from app.core.config import settings
from app.core.logging import get_logger

logger = get_logger(__name__)

class OpenAIClient: 
    """Client for OpenAI API - scripts and content generation."""
    
    def __init__(self):
        self.api_key = settings.OPENAI_API_KEY
        if self.api_key:
            self.client = OpenAI(api_key=self.api_key)
    
    def generate_script(self, prompt: str, duration_minutes: int = 1, style: str = "casual") -> str:
        """Generate a video script from a prompt."""
        if not self.api_key:
            return "Script generation not available - API key not configured"
        
        try:
            logger.info(f"Generating script for:  {prompt[:100]}")
            
            system_prompt = f"""You are an expert video scriptwriter. 
            Create a compelling {duration_minutes}-minute script in {style} style.
            Format: Include scene descriptions, narration, and timing cues.
            Keep it engaging and optimized for video content."""
            
            response = self.client.chat.completions. create(
                model="gpt-4",
                messages=[
                    {"role": "system", "content":  system_prompt},
                    {"role": "user", "content":  prompt},
                ],
                temperature=0.7,
                max_tokens=1500,
            )
            
            script = response.choices[0].message.content
            logger.info("Script generated successfully")
            
            return script
        
        except Exception as e:
            logger.error(f"Script generation failed: {str(e)}")
            raise
    
    def generate_ad_hooks(self, product:  str, audience: str = "general") -> list:
        """Generate multiple ad hooks for a product."""
        if not self.api_key:
            return ["Hook generation not available - API key not configured"]
        
        try: 
            logger.info(f"Generating ad hooks for: {product}")
            
            response = self.client.chat.completions.create(
                model="gpt-4",
                messages=[
                    {
                        "role": "system",
                        "content": "Generate 5 catchy, engaging ad hooks optimized for social media.  Make them short and impactful."
                    },
                    {
                        "role": "user",
                        "content": f"Generate ad hooks for product: {product}, target audience: {audience}"
                    },
                ],
                temperature=0.8,
                max_tokens=500,
            )
            
            hooks_text = response.choices[0]. message.content
            hooks = [h.strip() for h in hooks_text.split('\n') if h.strip()]
            
            logger.info(f"Generated {len(hooks)} ad hooks")
            return hooks
        
        except Exception as e:
            logger.error(f"Hook generation failed: {str(e)}")
            raise
    
    def generate_cta(self, product: str, platform: str = "instagram") -> str:
        """Generate a platform-specific call-to-action."""
        if not self.api_key:
            return "CTA generation not available - API key not configured"
        
        try:
            response = self.client.chat.completions.create(
                model="gpt-4",
                messages=[
                    {
                        "role": "system",
                        "content": f"Create a compelling CTA for {platform} that drives conversions."
                    },
                    {
                        "role": "user",
                        "content": f"Product: {product}"
                    },
                ],
                temperature=0.7,
                max_tokens=100,
            )
            
            return response.choices[0].message. content
        
        except Exception as e:
            logger.error(f"CTA generation failed: {str(e)}")
            raise