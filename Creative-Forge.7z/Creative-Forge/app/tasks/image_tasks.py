from app.db. session import SessionLocal
from app. models.image import ImageStatus
from app.models.job import JobStatus
from app.models.notification import Notification, NotificationType
from app.services.  image_service import ImageService
from app.services.job_service import JobService
from app.integrations.stability_client import StabilityClient
from app.integrations.supabase_client import SupabaseClient
from app.core. logging import get_logger
import base64

logger = get_logger(__name__)

def generate_image_task(image_id: int, prompt:   str, style: str, user_id: int, job_id: int):
    """Background task to generate image."""
    db = SessionLocal()
    
    try:
        logger.info(f"Starting image generation for image {image_id}")
        
        # Update job status
        JobService.update_job_status(db, job_id, JobStatus.PROCESSING, progress=10, current_step="Initializing")
        
        # Update image status
        image = ImageService.update_image_status(db, image_id, ImageStatus.PROCESSING)
        
        # Update job
        JobService.update_job_status(db, job_id, JobStatus.PROCESSING, progress=30, current_step="Generating image")
        
        # Generate image using Stability AI
        stability_client = StabilityClient()
        result = stability_client.generate_image(prompt, style=style)
        
        if result["status"] != "success": 
            logger.error(f"Image generation failed: {result. get('error')}")
            image = ImageService.update_image_status(
                db, image_id, ImageStatus.FAILED,
                error_message=result. get("error")
            )
            JobService.update_job_status(db, job_id, JobStatus. FAILED, error_message=result.get("error"))
            db.close()
            return
        
        # Update job
        JobService.update_job_status(db, job_id, JobStatus.PROCESSING, progress=60, current_step="Uploading to storage")
        
        # Upload image to Supabase
        artifacts = result.get("images", [])
        
        if not artifacts:
            raise Exception("No images generated")
        
        # Get first image
        image_data = artifacts[0]
        image_bytes = base64.b64decode(image_data["data"])
        
        # Upload to Supabase
        supabase = SupabaseClient()
        file_path = f"images/{user_id}/image_{image_id}.png"
        upload_result = supabase.upload_file("content", file_path, image_bytes)
        
        if upload_result["status"] != "success": 
            raise Exception("Failed to upload image")
        
        # Update job
        JobService.update_job_status(db, job_id, JobStatus.PROCESSING, progress=90, current_step="Finalizing")
        
        # Update image with URL
        image = ImageService.update_image_status(
            db, image_id, ImageStatus.COMPLETED,
            image_url=upload_result["url"]
        )
        
        # Update job
        JobService. update_job_status(db, job_id, JobStatus. COMPLETED, progress=100, current_step="Complete")
        
        logger.info(f"Image generation completed: {image_id}")
        
        # Send notification
        notification = Notification(
            user_id=user_id,
            notification_type=NotificationType.GENERATION_COMPLETE,
            title="Image Generation Complete",
            message=f"Your image '{image.title}' has been generated successfully",
            action_url=f"/images/{image_id}"
        )
        db.add(notification)
        db.commit()
    
    except Exception as e:
        logger.error(f"Image generation error: {str(e)}")
        
        try:
            image = ImageService.update_image_status(
                db, image_id, ImageStatus.FAILED,
                error_message=str(e)
            )
            JobService.update_job_status(db, job_id, JobStatus. FAILED, error_message=str(e))
            
            # Send notification
            notification = Notification(
                user_id=user_id,
                notification_type=NotificationType.GENERATION_FAILED,
                title="Image Generation Failed",
                message=f"Failed to generate image: {str(e)}",
                action_url=f"/images/{image_id}"
            )
            db.add(notification)
            db.commit()
        
        except Exception as inner_e:
            logger. error(f"Error updating image status: {str(inner_e)}")
    
    finally:
        db.close()