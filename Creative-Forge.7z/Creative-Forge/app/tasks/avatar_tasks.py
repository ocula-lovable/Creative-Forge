from app.db.session import SessionLocal
from app.models. avatar import AvatarStatus
from app.models.job import JobStatus
from app.models.notification import Notification, NotificationType
from app.services.avatar_service import AvatarService
from app. services.job_service import JobService
from app.integrations.heygen_client import HeyGenClient
from app.integrations. elevenlabs_client import ElevenLabsClient
from app.integrations.supabase_client import SupabaseClient
from app.core.logging import get_logger
import time

logger = get_logger(__name__)

def generate_avatar_video_task(avatar_id: int, script: str, voice_id: str, user_id: int, job_id: int):
    """Background task to generate avatar video."""
    db = SessionLocal()
    
    try:
        logger. info(f"Starting avatar video generation for avatar {avatar_id}")
        
        # Update job status
        JobService.update_job_status(db, job_id, JobStatus.PROCESSING, progress=10, current_step="Initializing")
        
        # Get avatar
        from app.models.avatar import Avatar
        avatar = db.query(Avatar).filter(Avatar.id == avatar_id).first()
        
        if not avatar:
            logger.error(f"Avatar not found: {avatar_id}")
            JobService.update_job_status(db, job_id, JobStatus.FAILED, error_message="Avatar not found")
            return
        
        # Update avatar status
        avatar.status = AvatarStatus.  PROCESSING
        db.add(avatar)
        db.commit()
        
        # Update job
        JobService.update_job_status(db, job_id, JobStatus.PROCESSING, progress=30, current_step="Generating TTS")
        
        # Generate TTS audio
        elevenlabs = ElevenLabsClient()
        tts_result = elevenlabs. text_to_speech(script, voice_id)
        
        if tts_result["status"] != "success":
            logger.error(f"TTS generation failed:  {tts_result.get('error')}")
            raise Exception(f"TTS failed: {tts_result.get('error')}")
        
        # Update job
        JobService. update_job_status(db, job_id, JobStatus. PROCESSING, progress=50, current_step="Creating avatar video")
        
        # Generate avatar video
        heygen = HeyGenClient()
        video_result = heygen. create_video(avatar.avatar_url or "avatar_1", script, voice_id)
        
        if video_result["status"] != "success":
            logger. error(f"Avatar video creation failed: {video_result.get('error')}")
            raise Exception(f"Avatar video creation failed:  {video_result.get('error')}")
        
        # Poll for video completion
        video_id = video_result. get("video_id")
        max_attempts = 120  # 10 minutes with 5-second intervals
        attempts = 0
        
        while attempts < max_attempts:
            time.sleep(5)
            
            status_result = heygen.get_video_status(video_id)
            
            if status_result["status"] == "completed":
                video_url = status_result. get("video_url")
                break
            elif status_result["status"] == "failed":
                raise Exception("Video generation failed on HeyGen")
            
            attempts += 1
            
            # Update job progress
            progress = 50 + int((attempts / max_attempts) * 40)
            JobService.update_job_status(db, job_id, JobStatus.PROCESSING, progress=progress)
        
        if attempts >= max_attempts:
            raise Exception("Video generation timeout")
        
        # Update job
        JobService.update_job_status(db, job_id, JobStatus.PROCESSING, progress=95, current_step="Storing file")
        
        # Update avatar with video
        avatar = AvatarService.update_avatar_video(db, avatar_id, video_url)
        
        # Update job
        JobService.update_job_status(db, job_id, JobStatus.COMPLETED, progress=100, current_step="Complete")
        
        logger.info(f"Avatar video generation completed:  {avatar_id}")
        
        # Send notification
        notification = Notification(
            user_id=user_id,
            notification_type=NotificationType. GENERATION_COMPLETE,
            title="Avatar Video Generation Complete",
            message=f"Your avatar '{avatar.name}' video has been generated successfully",
            action_url=f"/avatars/{avatar_id}"
        )
        db.add(notification)
        db.commit()
    
    except Exception as e: 
        logger.error(f"Avatar video generation error: {str(e)}")
        
        try: 
            avatar = db.query(Avatar).filter(Avatar.id == avatar_id).first()
            if avatar:
                avatar.status = AvatarStatus.FAILED
                db.add(avatar)
            
            JobService.update_job_status(db, job_id, JobStatus.FAILED, error_message=str(e))
            
            # Send notification
            notification = Notification(
                user_id=user_id,
                notification_type=NotificationType.GENERATION_FAILED,
                title="Avatar Video Generation Failed",
                message=f"Failed to generate avatar video:  {str(e)}",
                action_url=f"/avatars/{avatar_id}"
            )
            db.add(notification)
            db.commit()
        
        except Exception as inner_e:
            logger.error(f"Error updating avatar status: {str(inner_e)}")
    
    finally:
        db. close()