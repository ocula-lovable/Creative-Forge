from app.db.session import SessionLocal
from app.models.job import JobStatus
from app.models.notification import Notification, NotificationType
from app.services.job_service import JobService
from app.integrations.supabase_client import SupabaseClient
from app.core.logging import get_logger
import os
import tempfile
import subprocess
import requests

logger = get_logger(__name__)

def export_project_task(project_id: int, job_id: int, format: str, quality: str, user_id: int):
    """Background task to export project."""
    db = SessionLocal()
    
    try:
        logger.info(f"Starting project export:   {project_id}")
        
        from app.models.project import Project
        project = db.query(Project).filter(Project.id == project_id).first()
        
        if not project:
            logger.error(f"Project not found: {project_id}")
            return
        
        # Update job status
        JobService.update_job_status(db, job_id, JobStatus.PROCESSING, progress=10, current_step="Preparing files")
        
        # Collect all videos from project
        videos = project.videos
        
        if not videos: 
            logger.warning(f"No videos in project: {project_id}")
            JobService.update_job_status(db, job_id, JobStatus.COMPLETED, progress=100)
            db.close()
            return
        
        # Download videos
        supabase = SupabaseClient()
        temp_dir = tempfile.mkdtemp()
        video_files = []
        
        for i, video in enumerate(videos):
            if not video.video_url:
                continue
            
            try:
                # Download video
                response = requests.get(video. video_url)
                temp_file = os.path.join(temp_dir, f"video_{i}.mp4")
                
                with open(temp_file, 'wb') as f:
                    f.write(response. content)
                
                video_files.append(temp_file)
            except Exception as e:
                logger.warning(f"Failed to download video {i}: {str(e)}")
            
            progress = 10 + int((i / len(videos)) * 30)
            JobService.update_job_status(db, job_id, JobStatus.PROCESSING, progress=progress, current_step=f"Downloaded {i+1}/{len(videos)}")
        
        if not video_files:
            logger.warning(f"No video files to export: {project_id}")
            JobService.update_job_status(db, job_id, JobStatus.COMPLETED, progress=100)
            db.close()
            return
        
        # Concatenate videos
        JobService.update_job_status(db, job_id, JobStatus.PROCESSING, progress=50, current_step="Merging videos")
        
        if len(video_files) > 1:
            concat_file = os.path.join(temp_dir, "concat.txt")
            with open(concat_file, 'w') as f:
                for vf in video_files:
                    f.write(f"file '{vf}'\n")
            
            output_file = os.path.join(temp_dir, f"export. {format}")
            
            try:
                # Use ffmpeg to concatenate
                cmd = [
                    'ffmpeg', '-f', 'concat', '-safe', '0',
                    '-i', concat_file, '-c', 'copy', output_file
                ]
                subprocess.run(cmd, check=True, capture_output=True)
            except subprocess.CalledProcessError as e:
                logger.error(f"FFmpeg error: {str(e)}")
                raise Exception("Failed to merge videos")
        else:
            output_file = video_files[0]
        
        # Update job
        JobService.update_job_status(db, job_id, JobStatus.PROCESSING, progress=80, current_step="Uploading export")
        
        # Upload export to Supabase
        with open(output_file, 'rb') as f:
            export_bytes = f.read()
        
        export_path = f"exports/{user_id}/project_{project_id}/export. {format}"
        upload_result = supabase.upload_file("content", export_path, export_bytes)
        
        if upload_result["status"] != "success":
            raise Exception("Failed to upload export")
        
        # Update job
        JobService.update_job_status(db, job_id, JobStatus.COMPLETED, progress=100, current_step="Complete")
        
        logger.info(f"Project export completed: {project_id}")
        
        # Send notification
        notification = Notification(
            user_id=user_id,
            notification_type=NotificationType. GENERATION_COMPLETE,
            title="Project Export Complete",
            message=f"Your project '{project.title}' has been exported successfully",
            action_url=f"/projects/{project_id}"
        )
        db.add(notification)
        db.commit()
        
        # Cleanup
        for f in video_files:
            try:
                os.remove(f)
            except: 
                pass
        try:
            os.rmdir(temp_dir)
        except:
            pass
    
    except Exception as e:
        logger. error(f"Export error: {str(e)}")
        
        try:
            JobService.update_job_status(db, job_id, JobStatus.FAILED, error_message=str(e))
            
            # Send notification
            notification = Notification(
                user_id=user_id,
                notification_type=NotificationType.GENERATION_FAILED,
                title="Project Export Failed",
                message=f"Failed to export project: {str(e)}",
            )
            db.add(notification)
            db.commit()
        
        except Exception as inner_e:
            logger.error(f"Error updating job status: {str(inner_e)}")
    
    finally:
        db.close()