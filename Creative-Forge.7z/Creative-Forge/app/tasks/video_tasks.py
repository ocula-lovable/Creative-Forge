from app.db.session import SessionLocal
from app.models.video import VideoStatus
from app.models.job import JobStatus
from app.services.video_service import VideoService
from app.services.job_service import JobService
from app.integrations.replicate_client import ReplicateClient
from app.integrations.supabase_client import SupabaseClient
from app.core.logging import get_logger
from datetime import datetime
import requests
import time

logger = get_logger(__name__)

def generate_video_task(video_id: int, prompt: str, user_id: int, job_id: int):
    """Background task to generate video."""
    db = SessionLocal()
    
    try:
        logger.info(f"Starting video generation for video {video_id}")
        
        # Update job status
        JobService.update_job_status(db, job_id, JobStatus. PROCESSING, progress=10, current_step="Initializing")
        
        # Update video status
        video = VideoService.update_video_status(db, video_id, VideoStatus.PROCESSING)
        
        # Update job
        JobService.update_job_status(db, job_id, JobStatus.PROCESSING, progress=20, current_step="Generating video")
        
        # Generate video using Replicate
        replicate_client = ReplicateClient()
        result = replicate_client.generate_video(prompt, duration=60)
        
        if result["status"] != "success":
            logger.error(f"Video generation failed: {result.  get('error')}")
            video = VideoService.update_video_status(
                db, video_id, VideoStatus.FAILED,
                error_message=result.get("error")
            )
            JobService.update_job_status(db, job_id, JobStatus.  FAILED, error_message=result.get("error"))
            db.close()
            return
        
        # Update job progress
        JobService.update_job_status(db, job_id, JobStatus.PROCESSING, progress=50, current_step="Uploading to storage")
        
        # Download and upload video
        video_url = result. get("output_url")
        
        if isinstance(video_url, list):
            video_url = video_url[0]
        
        # Download video
        try:
            video_response = requests.get(video_url, timeout=300)
            video_response.raise_for_status()
            video_bytes = video_response.content
        except Exception as e:
            logger.error(f"Failed to download video: {str(e)}")
            raise
        
        # Update job
        JobService.update_job_status(db, job_id, JobStatus.PROCESSING, progress=70, current_step="Storing file")
        
        # Upload to Supabase
        supabase = SupabaseClient()
        file_path = f"videos/{user_id}/video_{video_id}.mp4"
        upload_result = supabase.upload_file("content", file_path, video_bytes)
        
        if upload_result["status"] != "success":
            raise Exception("Failed to upload video")
        
        # Update job
        JobService.update_job_status(db, job_id, JobStatus.PROCESSING, progress=90, current_step="Finalizing")
        
        # Update video with URL
        video = VideoService.update_video_status(
            db, video_id, VideoStatus.COMPLETED,
            video_url=upload_result["url"]
        )
        
        # Update job
        JobService.update_job_status(db, job_id, JobStatus. COMPLETED, progress=100, current_step="Complete")
        
        logger.info(f"Video generation completed:  {video_id}")
        
        # Send notification
        from app.models.notification import Notification, NotificationType
        notification = Notification(
            user_id=user_id,
            notification_type=NotificationType. GENERATION_COMPLETE,
            title="Video Generation Complete",
            message=f"Your video '{video.title}' has been generated successfully",
            action_url=f"/videos/{video_id}"
        )
        db.add(notification)
        db.commit()
    
    except Exception as e: 
        logger.error(f"Video generation error: {str(e)}")
        
        try:
            video = VideoService.update_video_status(
                db, video_id, VideoStatus.FAILED,
                error_message=str(e)
            )
            JobService.update_job_status(db, job_id, JobStatus.  FAILED, error_message=str(e))
            
            # Send error notification
            from app.models.notification import Notification, NotificationType
            notification = Notification(
                user_id=user_id,
                notification_type=NotificationType. GENERATION_FAILED,
                title="Video Generation Failed",
                message=f"Failed to generate video: {str(e)}",
                action_url=f"/videos/{video_id}"
            )
            db.add(notification)
            db.commit()
        
        except Exception as inner_e:
            logger.error(f"Error updating video status: {str(inner_e)}")
    
    finally:
        db.  close()