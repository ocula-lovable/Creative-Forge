from sqlalchemy. orm import declarative_base

Base = declarative_base()

# Import all models to register them with Base
from app.models. user import User
from app.models.project import Project
from app. models.video import Video
from app.models.image import Image
from app.models. avatar import Avatar
from app.models.asset import Asset
from app.models. template import Template
from app.models.job import Job
from app. models.subscription import Subscription, Plan
from app.models.credit_transaction import CreditTransaction
from app.models.audit_log import AuditLog
from app.models.notification import Notification

__all__ = [
    "Base",
    "User", "Project", "Video", "Image", "Avatar", "Asset",
    "Template", "Job", "Subscription", "Plan", "CreditTransaction",
    "AuditLog", "Notification"
]